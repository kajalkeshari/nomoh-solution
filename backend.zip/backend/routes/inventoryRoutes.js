const express = require('express');
const router = express.Router();
const Inventory= require('../model/inventoryschema.js')
const multer = require('multer');
const path = require('path');
const fs = require('fs');



router.use('/uploads', express.static(path.join(__dirname, 'uploads')));


// Read (SELECT)
router.get('/read', async (req, res) => {
    try {
      const inventory = await Inventory.find();
      res.send(inventory);
    } catch (error) {
      console.error('Error reading inventory:', error);
      res.status(500).send('Internal Server Error');
    }
  });


  router.get('/read/:id', async (req, res) => {
    try {
      const inventoryItem = await Inventory.findById(req.params.id);
      if (!inventoryItem) {
        return res.status(404).send('Inventory item not found');
      }
      res.send(inventoryItem);
    } catch (error) {
      console.error('Error reading inventory:', error);
      res.status(500).send('Internal Server Error');
    }
  });
  
  router.get('/uploads/:imageName', (req, res) => {
    const imageName = req.params.imageName;
  
   // Adjust 
      const filePath = path.join('uploads', imageName); 

       console.log(imageName)
       console.log(filePath)
     
    try {
      // Read the image file synchronously
      fs.readFile(filePath, (err, data) => {
        if (err) {
          console.error(err);
          res.status(500).send('Error reading image file');
          return;
        }

        // Set the appropriate headers and send the image data as the response
        res.writeHead(200, {
          'Content-Type': 'image/jpeg',
          'Content-Length': data.length
        });
        res.end(data);
      });
   }   catch (error) {
      console.error('Error reading image:', error);
      res.status(500).send('Error reading image.');
    }


  });
  
  router.get('/find/image', (req, res) => {
    // Read the files in the 'uploads' directory
    fs.readdir('uploads', (err, files) => {
      if (err) {
        console.error('Error reading directory:', err);
        res.status(500).send('Error reading directory.');
        return;
      }
  
      // Send the list of filenames in the response
      res.json({ files });
    });
  });


  // Multer storage configuration
  const storage = multer.diskStorage({
    destination: function (req, file, cb) {
      cb(null, 'uploads/'); // Define the destination directory
    },
    filename: function (req, file, cb) {
      cb(null, file.fieldname + "_" + Date.now() + path.extname(file.originalname)); // Define the filename
    }
  });

  const upload = multer({ storage: storage }).single('image');



  // Image upload route
  router.post('/upload', upload, async (req, res) => {
    try {
      if (!req.file) {
        return res.status(400).json({ error: "No file uploaded" });
      }

      const imageFile = req.file.filename; // Get the uploaded file name

      res.status(200).json({ success: `${imageFile} uploaded successfully` });
    } catch (error) {
      console.error("Error uploading image:", error);
      res.status(500).json({ error: "Internal server error" });
    }
  });

  
  // Create (INSERT)
  router.post('/create', async (req, res) => {
    try {
      const { name, category, quantity, price ,date,status,image} = req.body;
      const inventory = new Inventory({ name, category, quantity,date, price,status,image:req.file});
      await inventory.save();
      res.send('Inventory added to database');
    } catch (error) {
      console.error('Error creating inventory:', error);
      res.status(500).send('Internal Server Error');
    }
  });

// Route to handle flagging items
router.post('/flag/:id', async (req, res) => {
  const { id } = req.params;

  try {
    // Find the item in the inventory by its ID
    const item = await Inventory.findById(id);
    if (!item) {
      return res.status(404).send('Item not found');
    }

    // Update the item's flagged status to true
    item.flagged = true;
    await item.save();

    

    res.status(200).send('Item flagged successfully');
  } catch (error) {
    console.error('Error flagging item:', error);
    res.status(500).send('Internal Server Error');
  }
});


// Verify a product
router.put('/verify/:id', async (req, res) => {
  try {
    const { id } = req.params;
    const inventoryItem = await Inventory.findByIdAndUpdate(id);
    if (!inventoryItem) {
      return res.status(404).send('Inventory item not found');
    }
    // Update status to "Verified"
    inventoryItem.status = 'Verified';
    await inventoryItem.save();
    res.status(200).send('Product verified');
  } catch (error) {
    console.error('Error verifying product:', error);
    res.status(500).send('Internal Server Error');
  }
});

// Reject a product
router.put('/reject/:id', async (req, res) => {
  try {
    const { id } = req.params;
    const inventoryItem = await Inventory.findByIdAndUpdate(id);
    if (!inventoryItem) {
      return res.status(404).send('Inventory item not found');
    }
    // Update status to "Rejected"
    inventoryItem.status = 'Rejected';
    await inventoryItem.save();
    res.status(200).send('Product rejected');
  } catch (error) {
    console.error('Error rejecting product:', error);
    res.status(500).send('Internal Server Error');
  }
});

 
  
 // Update (PUT)
router.put('/update/:id', async (req, res) => {
  try {
    const { name, category, quantity, price, status ,location,issue,totalquantity} = req.body;
    const updateInventory = await Inventory.findByIdAndUpdate(
      req.params.id,
      { name, category, quantity, price, status,location,issue,totalquantity },
      { new: true }
    );
    res.status(200).json({ message: 'Inventory updated successfully', inventory: updateInventory });
  } catch (error) {
    res.status(400).json({ message: error.message });
  }
});

  
  
  
  // Delete (DELETE)
  router.delete('/delete/:id', async (req, res) => {
    try {
      const id = req.params.id;
      await Inventory.findByIdAndDelete(id);
      res.send('Inventory deleted');
    } catch (error) {
      console.error('Error deleting inventory:', error);
      res.status(500).send('Internal Server Error');
    }
  });





  
  module.exports = router;