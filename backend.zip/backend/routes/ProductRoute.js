const express=require('express')
const { createProduct, getProduct } = require('../controller/productController')

const router=express.Router()


router.route('/create_product').post(createProduct)
router.route('/read').get(getProduct)

module.exports=router;