const mongoose = require('mongoose');



// / Define Inventory Schema
const inventorySchema = new mongoose.Schema({
  name: {
    type: String,
    required: true
},
category: {
    type: String,
    required: true
},
quantity: {
    type: Number,
    required: true
},
// qedit: {
//     type: String,
// //   default:''
// },
issue: {
    type: Number,
//   default:''
    
},
totalquantity: {
    type: Number,
    // default:''

},
location: {
    type: String,
   
},
price: {
    type: String,
    required: true
},
date: {
    type: Date,
    // required: true
},
image:String,
status: {
    type: String,
    // enum: ['pending', 'completed'], 
    default: 'pending' 
},
flagged: Boolean,
});

module.exports = mongoose.model('Inventory', inventorySchema);