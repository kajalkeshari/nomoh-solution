import * as React from 'react';
// import { BrowserRouter as Router, Route, Switch, Routes } from 'react-router-dom';
import { ChakraProvider } from '@chakra-ui/react';
import { useSelector } from 'react-redux';
import Login from './pages/Login';
import Department from './pages/Department';
import VerifyProduct from './pages/VerifyProduct';
import Tabbar from './pages/Tabbar';
import Navbar from './pages/Navbar';
import CRM from './pages/Crm';
import Sidebar from './pages/Sidebar';




function App() {
  const { isAuthenticated, data,isLoading } = useSelector((state) => state.authReducer);
  console.log(data);
let department;
if(data&&data.department){
  department=data.department.department
console.log(department)
}

const handleLoginAlert = () => {
  if (isAuthenticated) {
    let roleName = '';
    if (department === 'Marketing Manager') {
      roleName = 'Marketing Manager';
    
    } else if (department === 'Marketing Excutive') {
      
      roleName = 'Marketing Excutive';
    } else if (department === 'Store') {
      
      roleName = 'Store';
    } 
    alert(`${roleName} login successfully.`);
  }
};


React.useEffect(() => {
  handleLoginAlert();
}, [isAuthenticated]);

const HandlePage=()=>{
  if (isLoading) {
    return <div>Loading...</div>; 
  }

  switch(department) {
    case "Marketing Manager":
      return(
<>
       {/* <Department/> */}
       <Sidebar/>
</>

      )
      break;
//       case "Store":
//       return(
// <>
        
//        <Tabbar/>
// </>

//       )
//       break;
    case "Marketing Excutive":
  
    return(
<>

<Navbar/>



</>

    );
      break;
    default:
      
  }
  


}



  return (
    <ChakraProvider>
     
 
          {isAuthenticated?(<>
            
          <HandlePage/>
        
          </>):(<><Login/></>)}    
         
     {/* <Navbar/> */}
     {/* <Sidebar/> */}

    </ChakraProvider>
  );
}

export default App;





