import React from 'react';
import { BrowserRouter as Router, Routes, Route, Link } from 'react-router-dom';
import Schedule from './pages/Schedule';
import CRM from './pages/Crm';
import AdjustCustomer from './pages/AdjustCustomer';
import CustomerSatisfaction from './pages/Satisfaction';
import Order from './pages/Order';





function Main() {
  return (
    // <Router>
      <Routes>
         {/* <Route path="/create_product" element={<Manageinventory />} /> 
        <Route path="/product_veri" element={<VerifyProduct/>} /> */}
        <Route path="/schedule" element={<Schedule/>} /> 
        <Route path="/" element={<CRM />} />
        <Route path="/adjust_customer" element={<AdjustCustomer/>   } />
        <Route path="/satisfy_customer" element={<CustomerSatisfaction/>  } />
        <Route path="/order" element={<Order/>  } />

      </Routes>
    // </Router>
  );
}

export default Main;
