import React, { useState, useEffect } from "react";
import axios from "axios";
import { EditIcon, DeleteIcon } from "@chakra-ui/icons";
import { Button, Text, Heading, Box, Input, Flex, HStack, Table, Drawer, FormLabel, DrawerOverlay, DrawerContent, DrawerCloseButton, DrawerHeader, DrawerBody, Thead, Tbody, Tr, Th, Select, Img, Td, Center, DrawerFooter, Divider, Stack, } from "@chakra-ui/react";
const  backend_url=process.env.REACT_APP_URL;

const AdjustCustomer = () => {
  const [customers, setCustomers] = useState([]);
  const [customerFormData, setCustomerFormData] = useState("");
  const [interestedCustomers, setInterestedCustomers] = useState([]);
  const [notInterestedCustomers, setNotInterestedCustomers] = useState([]);
  const [isDrawerOpen, setIsDrawerOpen] = useState(false);
  const [selectedCustomer, setSelectedCustomer] = useState(null);
  const [isEditMode, setIsEditMode] = useState(false);



  useEffect(() => {
    fetchCustomers();
  }, []);

  const fetchCustomers = async () => {
    try {
      const response = await axios.get(`${backend_url}/api/read_customers`);
      const data = response.data;
      setCustomers(data);

      const interested = data.filter((customer) => customer.date === "Interested");
      const notInterested = data.filter((customer) => customer.date === "Not Interested");

      const interestedWithDate = interested.map(customer => ({ ...customer, date: 'Interested' }));

      setInterestedCustomers(interestedWithDate);
      setNotInterestedCustomers(notInterested);
    } catch (error) {
      console.error("Error fetching customers:", error);
    }
  };




  const deleteCustomer = async (customerId) => {
    try {
      if (window.confirm("Are you sure you want to delete this customer?")) {
        await axios.delete(`${backend_url}/api/delete_customer/${customerId}`);
        alert("Customer deleted successfully.");
        await fetchCustomers();
      }
    } catch (error) {
      console.error("Error deleting customer:", error);
    }
  };

  const handleImageInputChange = (e) => {
    setCustomerFormData({
      ...customerFormData,
      image: e.target.files[0], // Save the selected image file
    });
  };


  // const handleInputChange = (e) => {
  //   setCustomerFormData({ ...customerFormData, [e.target.name]: e.target.value });
  // };

  const handleCustomerInputChange = (e) => {
    setCustomerFormData({ ...customerFormData, [e.target.name]: e.target.value });
  };





  const AddCustomer = async () => {
    try {
      if (!customerFormData) {
        alert("Please fill in all required fields.");
        return;
      }


      // Create a FormData object to handle multipart/form-data
      const formData = new FormData();
      formData.append('date', customerFormData.date);
      formData.append('srno', customerFormData.srno);
      formData.append('companyName', customerFormData.companyName);

      formData.append('customerName', customerFormData.customerName);
      formData.append('scheduledate', customerFormData.scheduledate);
      formData.append('customerNumber', customerFormData.customerNumber);
      formData.append('email', customerFormData.email);
      formData.append('city', customerFormData.city);
      formData.append('office', customerFormData.office);
      formData.append('state', customerFormData.state);
      formData.append('businessCategory', customerFormData.businessCategory);
      formData.append('requiredItem', customerFormData.requiredItem);
      formData.append('requiredQuantity', customerFormData.requiredQuantity);
      formData.append('productSpecific', customerFormData.productSpecific);
      formData.append('orderValue', customerFormData.orderValue);
      formData.append('feasibility', customerFormData.feasibility);
      formData.append('quotationSubmissionDate', customerFormData.quotationSubmissionDate);
      formData.append('followingResult', customerFormData.followingResult);
      formData.append('image', customerFormData.image);




      // Send POST request with FormData
      const response = await axios.post(`${backend_url}/api/add_customer`, formData, {
        headers: {
          'Content-Type': 'multipart/form-data'
        }
      });

      const newCustomer = response.data;
      await fetchCustomers();

      setCustomers([...customers, newCustomer]);
      setCustomerFormData({
        date: "",
        srno: "",
        companyName: "",
        customerName: "",
        scheduledate: "",
        customerNumber: "",
        email: "",
        city: "",
        office: "",
        state: "",
        businessCategory: "",
        requiredItem: "",
        requiredQuantity: "",
        productSpecific: "",
        orderValue: "",
        feasibility: "",
        quotationSubmissionDate: "",
        followingResult: "",
        image: null
      });


      alert("Customer added successfully.");
    } catch (error) {
      console.error("Error adding customer:", error);
      console.log(error);
    }
  };


  const handleEditCustomer = (customer) => {
    setSelectedCustomer(customer);
    setCustomerFormData(customer);
    setIsEditMode(true);
    setIsDrawerOpen(true);
  };




  const handleUpdateCustomer = async () => {
    try {
      // Send update request to the server
      const response = await axios.put(`${backend_url}/api/update_customer/${selectedCustomer._id}`, customerFormData);
      console.log(response.data);
      alert("Customer updated successfully.");
      await fetchCustomers();
      setIsDrawerOpen(false);
      setSelectedCustomer(null);
      setCustomerFormData({
        date: "",
        srno: "",
        companyName: "",
        customerName: "",
        scheduledate: "",
        customerNumber: "",
        email: "",
        city: "",
        office: "",
        state: "",
        businessCategory: "",
        requiredItem: "",
        requiredQuantity: "",
        productSpecific: "",
        orderValue: "",
        feasibility: "",
        quotationSubmissionDate: "",
        followingResult: "",
        image: null
      });
    } catch (error) {
      console.error("Error updating customer:", error);
    }
  };

  function formatDate(datetime) {
    const date = new Date(datetime);
    const year = date.getFullYear();
    const month = String(date.getMonth() + 1).padStart(2, '0'); // Months are zero-based in JavaScript
    const day = String(date.getDate()).padStart(2, '0');
    return `${year}-${month}-${day}`;
  }

  return (
    <Box borderWidth="2px" p={4} bg="white" color={'navy'} h={'100vh'}>
      {/* <Flex justifyContent="space-between" alignItems="center"> */}
      <Box w={{ base: "70%", md: "80%" }} >
        <Heading fontSize={{ base: '24px', md: '25px' }} mb={4}>Adjusting Customers</Heading>












        {/* DataTable for Interested Customers */}
        <Box p={4} >
          <Heading fontSize={'20'} color={'navy'} fontWeight={'900'} p={3}>Interested Customer Lead</Heading>
          <Box overflowX="auto" w={'75%'} borderRadius={8}>
            <Table variant="striped" colorScheme="blue" display={'block'} size='sm'  >
              <Thead bg={'navy'}>
                <Tr >
                  {/* <Th fontSize={'11'} color={'gray.200'}>Sr. No.</Th> */}
                  {/* <Th fontSize={'11'} textAlign={'center'} color={'gray.200'}>Image</Th> */}
                  <Th fontSize={'11'} textAlign={'center'} color={'gray.200'}>Follow Update</Th>
                  <Th fontSize={'11'} textAlign={'center'} color={'gray.200'}>Company Name</Th>
                  <Th fontSize={'11'} textAlign={'center'} color={'gray.200'}>City</Th>
                  <Th fontSize={'11'} textAlign={'center'} color={'gray.200'}>District</Th>
                  <Th fontSize={'11'} textAlign={'center'} color={'gray.200'}>State</Th>
                  <Th fontSize={'11'} textAlign={'center'} color={'gray.200'}>Customer Name</Th>
                  <Th fontSize={'11'} textAlign={'center'} color={'gray.200'}>Customer Number</Th>
                  <Th fontSize={'11'} textAlign={'center'} color={'gray.200'}>Email</Th>
                  <Th fontSize={'11'} textAlign={'center'} color={'gray.200'}>Business Category</Th>
                  <Th fontSize={'11'} textAlign={'center'} color={'gray.200'}>Required Item</Th>
                  <Th fontSize={'11'} textAlign={'center'} color={'gray.200'}>Required Quantity</Th>
                  <Th fontSize={'11'} textAlign={'center'} color={'gray.200'}>Product Specific</Th>
                  <Th fontSize={'11'} textAlign={'center'} color={'gray.200'}>Location</Th>
                  <Th fontSize={'11'} textAlign={'center'} color={'gray.200'}>Feasible / Not Feasible</Th>
                  <Th fontSize={'11'} textAlign={'center'} color={'gray.200'}>Meeting Date</Th>
                  <Th fontSize={'11'} textAlign={'center'} color={'gray.200'}>Schedule Date</Th>
                  <Th fontSize={'11'} textAlign={'center'} color={'gray.200'}>Following Result</Th>
                  {/* <Th fontSize={'11'} textAlign={'center'} color={'gray.200'}>Status</Th> */}
                  <Th fontSize={'11'} textAlign={'center'} color={'gray.200'}>Actions</Th>
                </Tr>
              </Thead>
              <Tbody>
                {interestedCustomers.map((customer, index) => (
                  <Tr key={index}>
                    {/* <Td fontSize={'11'}>{customer.srno}</Td> */}
                    {/* <Td fontSize={'11'} textAlign={'center'}>
                      <Img src={`./uploads/${customer.image}`} alt='profile '
                      />
                    </Td> */}

                    <Td fontSize={'11'} textAlign={'center'}>{customer.date}</Td>
                    <Td fontSize={'11'} textAlign={'center'}>{customer.companyName}</Td>
                    <Td fontSize={'11'} textAlign={'center'}>{customer.office}</Td>
                    <Td fontSize={'11'} textAlign={'center'}> {customer.city}</Td>
                    <Td fontSize={'11'} textAlign={'center'}>  {customer.state}</Td>
                    <Td fontSize={'11'} textAlign={'center'}>{customer.customerName}</Td>
                    <Td fontSize={'11'} textAlign={'center'}>{customer.customerNumber}</Td>
                    <Td fontSize={'11'} textAlign={'center'}>{customer.email}</Td>
                    <Td fontSize={'11'} textAlign={'center'}>{customer.businessCategory}</Td>
                    <Td fontSize={'11'} textAlign={'center'}>{customer.requiredItem}</Td>
                    <Td fontSize={'11'} textAlign={'center'}>{customer.requiredQuantity}</Td>
                    <Td fontSize={'11'} textAlign={'center'}>{customer.productSpecific}</Td>
                    <Td fontSize={'11'} textAlign={'center'}>{customer.orderValue}</Td>
                    <Td fontSize={'11'} textAlign={'center'}>{customer.feasibility}</Td>
                    <Td fontSize={'11'} textAlign={'center'}>{formatDate(customer.quotationSubmissionDate)}</Td>
                    <Td fontSize={'11'} textAlign={'center'}>{formatDate(customer.scheduledate)}</Td>
                    <Td fontSize={'11'} textAlign={'center'}>{customer.followingResult}</Td>
                    {/* <Td fontSize={'11'} textAlign={'center'}>{customer.status}</Td> */}
                    <Td>
                      <Flex justifyContent="center">
                        {/* <Button colorScheme="blue" h={6} w={5} variant="outline" onClick={() => handleEditCustomer(customer)} borderWidth="2px" mr={1}

                        >
                          <EditIcon />
                        </Button> */}
                        <Button colorScheme="blue" h={6} w={5} variant="outline" borderWidth="2px"
                          onClick={() => deleteCustomer(customer._id)}
                        >
                          <DeleteIcon />
                        </Button>
                      </Flex>
                    </Td>
                  </Tr>
                ))}
              </Tbody>
            </Table>
          </Box>
        </Box>















        <Box p={4}>
          <Heading fontSize={'20'} color={'navy'} fontWeight={'900'} p={3}>Not Interested Customer Lead</Heading>
          <Box overflowX="auto" w={'75%'} borderRadius={8}>
            <Table variant="striped" colorScheme="blue" size='sm' >
              <Thead bg={'navy'}>
                <Tr>
                  {/* <Th fontSize={'11'} color={'gray.200'}>Sr. No.</Th> */}
                  {/* <Th fontSize={'11'} textAlign={'center'} color={'gray.200'}>Image</Th> */}
                  <Th fontSize={'11'} textAlign={'center'} color={'gray.200'}>Follow Update</Th>
                  <Th fontSize={'11'} textAlign={'center'} color={'gray.200'}>Company Name</Th>
                  <Th fontSize={'11'} textAlign={'center'} color={'gray.200'}>City</Th>
                  <Th fontSize={'11'} textAlign={'center'} color={'gray.200'}>District</Th>
                  <Th fontSize={'11'} textAlign={'center'} color={'gray.200'}>State</Th>
                  <Th fontSize={'11'} textAlign={'center'} color={'gray.200'}>Customer Name</Th>
                  <Th fontSize={'11'} textAlign={'center'} color={'gray.200'}>Customer Number</Th>
                  <Th fontSize={'11'} textAlign={'center'} color={'gray.200'}>Email</Th>
                  <Th fontSize={'11'} textAlign={'center'} color={'gray.200'}>Business Category</Th>
                  <Th fontSize={'11'} textAlign={'center'} color={'gray.200'}>Required Item</Th>
                  <Th fontSize={'11'} textAlign={'center'} color={'gray.200'}>Required Quantity</Th>
                  <Th fontSize={'11'} textAlign={'center'} color={'gray.200'}>Product Specific</Th>
                  <Th fontSize={'11'} textAlign={'center'} color={'gray.200'}>Location</Th>
                  <Th fontSize={'11'} textAlign={'center'} color={'gray.200'}>Feasible / Not Feasible</Th>
                  <Th fontSize={'11'} textAlign={'center'} color={'gray.200'}>Meeting Date</Th>
                  <Th fontSize={'11'} textAlign={'center'} color={'gray.200'}>Schedule Date</Th>
                  <Th fontSize={'11'} textAlign={'center'} color={'gray.200'}>Following Result</Th>
                  {/* <Th fontSize={'11'} textAlign={'center'} color={'gray.200'}>Status</Th> */}
                  <Th fontSize={'11'} textAlign={'center'} color={'gray.200'}>Actions</Th>
                </Tr>
              </Thead>
              <Tbody>
                {notInterestedCustomers.map((customer, index) => (
                  <Tr key={index}>
                    {/* <Td fontSize={'11'}>{customer.srno}</Td> */}
                    {/* <Td fontSize={11} textAlign="center">
                      <Img src={`./uploads/${customer.image}`} alt="profile" />
                    </Td> */}


                    <Td fontSize={'11'} textAlign={'center'}>{customer.date}</Td>
                    <Td fontSize={'11'} textAlign={'center'}>{customer.companyName}</Td>
                    <Td fontSize={'11'} textAlign={'center'}>{customer.office}</Td>
                    <Td fontSize={'11'} textAlign={'center'}> {customer.city}</Td>
                    <Td fontSize={'11'} textAlign={'center'}>  {customer.state}</Td>
                    <Td fontSize={'11'} textAlign={'center'}>{customer.customerName}</Td>
                    <Td fontSize={'11'} textAlign={'center'}>{customer.customerNumber}</Td>
                    <Td fontSize={'11'} textAlign={'center'}>{customer.email}</Td>
                    <Td fontSize={'11'} textAlign={'center'}>{customer.businessCategory}</Td>
                    <Td fontSize={'11'} textAlign={'center'}>{customer.requiredItem}</Td>
                    <Td fontSize={'11'} textAlign={'center'}>{customer.requiredQuantity}</Td>
                    <Td fontSize={'11'} textAlign={'center'}>{customer.productSpecific}</Td>
                    <Td fontSize={'11'} textAlign={'center'}>{customer.orderValue}</Td>
                    <Td fontSize={'11'} textAlign={'center'}>{customer.feasibility}</Td>
                    <Td fontSize={'11'} textAlign={'center'}>{formatDate(customer.quotationSubmissionDate)}</Td>
                    <Td fontSize={'11'} textAlign={'center'}>{formatDate(customer.scheduledate)}</Td>
                    <Td fontSize={'11'} textAlign={'center'}>{customer.followingResult}</Td>
                    {/* <Td fontSize={'11'} textAlign={'center'}>{customer.status}</Td> */}
                    <Td>
                      <Flex justifyContent="center">
                        {/* <Button colorScheme="blue" h={6} w={5} variant="outline" onClick={() => handleEditCustomer(customer)} borderWidth="2px" mr={1}

                        >
                          <EditIcon />
                        </Button> */}
                        <Button colorScheme="blue" h={6} w={5} variant="outline" borderWidth="2px"
                          onClick={() => deleteCustomer(customer._id)}
                        >
                          <DeleteIcon />
                        </Button>
                      </Flex>
                    </Td>
                  </Tr>
                ))}
              </Tbody>
            </Table>
          </Box>
        </Box>
      </Box>
      </Box>
      );
};

      export default AdjustCustomer;
