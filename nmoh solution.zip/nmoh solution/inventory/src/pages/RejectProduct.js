import React, { useEffect, useState } from 'react';
import axios from 'axios';
import {
  Box,
  Text,
  ChakraProvider,
  Table,
  Thead,
  Tbody,
  Tr,
  Th,
  Td,
  Heading,
} from '@chakra-ui/react';
const  backend_url=process.env.REACT_APP_URL;

const RejectProduct = () => {
  const [data, setData] = useState([]);

  const fetchData = async () => {
    try {
      const response = await axios.get(`${backend_url}/api/read`);
      setData(response.data);
    } catch (error) {
      console.error('Error fetching data:', error);
    }
  };

  useEffect(() => {
    fetchData();
  }, []);

  const rejectedItems = data.filter(item => item.status === 'Rejected');

  function formatDate(datetime) {
    const date = new Date(datetime);
    const year = date.getFullYear();
    const month = String(date.getMonth() + 1).padStart(2, '0'); 
    const day = String(date.getDate()).padStart(2, '0');
    return `${year}-${month}-${day}`;
  }

  return (
    <Box p={4} borderWidth={'2px'} w={'100%'} color={'navy'}>
      
      <Box >
        <Heading textAlign={'center'} fontSize={'30'} p={4} color={'navy'}>Rejected Items</Heading>
        {rejectedItems.length > 0 ? (
          <Table variant="simple" mt={4}>
            <Thead bg={'blue.800'} fontSize={'10'} >
              <Tr>
                <Th color={'white'}>Name</Th>
                <Th color={'white'}>Port Number</Th>
                <Th color={'white'}>Category</Th>
                <Th color={'white'}>Date</Th>
                <Th color={'white'}>Status</Th>
                
              </Tr>
            </Thead>
            <Tbody bg={'blue.700'} color={'white'} fontSize={'12'}>
              {rejectedItems.map((item, index) => (
                <Tr key={index}>
                  <Td>{item.name}</Td>
                  <Td>{item.price}</Td>
                  <Td>{item.category}</Td>
                  <Td>{formatDate(item.date)}</Td>
                  <Td>{item.status}</Td>
                 
                </Tr>
              ))}
            </Tbody>
          </Table>
        ) : (
          <Text fontWeight={'bold'} fontSize={'25'}>No rejected items</Text>
        )}
      </Box>
    </Box>
  );
};

export default RejectProduct;
