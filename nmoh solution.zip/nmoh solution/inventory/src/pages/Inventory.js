import React from "react";
import Popup from "reactjs-popup";

import "reactjs-popup/dist/index.css";
import { useState, useEffect } from "react";
import { Button, Container,Select,Text, Image,FormControl, FormLabel, Heading,Input,Table,Tbody,Th,Thead, Tr, Flex,ButtonGroup,IconButton,Box,useToast,Icon, Td} from "@chakra-ui/react";
import axios from 'axios'
import {Link } from 'react-router-dom'
import { AiFillEdit,AiTwotoneDelete } from "react-icons/ai";
import { MdOutlineNextPlan } from "react-icons/md";
const  backend_url=process.env.REACT_APP_URL;
// import Tabbar from "./Tabbar";
// import Tabbar from "./Tabbar";
function Inventory({ image }) {
  const [data, setData] = useState([]);
  const [name, setName] = useState("");
  const [category, setCategory] = useState("");
  const [quantity, setQuantity] = useState("");
  const [price, setPrice] = useState("");
  const [date, setDate] = useState("");
  // const [image, setImage] = useState(null);
  const [searchQuery, setSearchQuery] = useState("");
const toast=useToast();
  useEffect(() => {
  
    getAllItems();
  }, []);



  

  const getAllItems = async () => {
    try {
      const response = await axios.get(`${backend_url}/api/read`);
      setData(response.data);
    } catch (error) {
      console.error('Error fetching inventory:', error);
      toast({
        title: 'Error fetching inventory',
        status: 'error',
        duration: 2000,
        isClosable: true,
      });
    }
  };

 
  
  
  const getSingleItemHandler = async (id) => {
    try {
      const response = await axios.get(`${backend_url}/api/read/${id}`);
      const itemDetails = response.data;
      
      setName(itemDetails.name);
      setPrice(itemDetails.price);
      setCategory(itemDetails.category);
      setQuantity(itemDetails.quantity);
      setDate(itemDetails.date);
    } catch (error) {
      console.error('Error fetching item details:', error);
      toast({
        title: 'Error fetching item details',
        status: 'error',
        duration: 2000,
        isClosable: true,
      });
    }
  };
  

  const clearStateValue=()=>{
    setCategory("");
    setPrice("");
    setName("");
    setQuantity("");
    setDate("");
  }


  
    // const handleFlagItem = async (id) => {
    //   try {
    //     // Make an API call to flag the item
    //     await axios.post(`${backend_url}/api/flag/${id}`);
    //     alert('Item flagged successfully!');
    //   } catch (error) {
    //     console.error('Error flagging item:', error);
    //     alert('An error occurred while flagging the item. Please try again later.');
    //   }
    // };
 

 // Update Functionality
const updateItemHandler = async (id) => {
  try {
    if (name === "" || category === "" || quantity === "" || price === "") {
      alert("Please enter all the values");
    } else {
      const response = await axios.put(`${backend_url}/api/update/${id}`, {
        name,
        category,
        quantity,
        price,
        date
      });

      // Assuming the server responds with the updated item data
      const updatedItem = response.data;
      getAllItems();
      toast({
        title: 'Product updated.',
        status: 'success',
        duration: 2000,
        isClosable: true,
      });

      // Update the specific item in the data state with the updated data
      // setData(data.map(item => item._id === id ? updatedItem : item));
      setData(prevData => prevData.map(item => item._id === id ? updatedItem : item));
      // Clear input fields
      clearStateValue();
    }
  } catch (error) {
    console.error('Error updating item:', error);
    toast({
      title: 'Error updating product',
      status: 'error',
      duration: 2000,
      isClosable: true,
    });
  }
};

  
  const deleteItemHandler = async (id) => {
    try {
      await axios.delete(`${backend_url}/api/delete/${id}`);
      // Fetch all items after successful deletion
      getAllItems();
      toast({
        title: 'Product deleted',
        status: 'success',
        duration: 2000,
        isClosable: true,
      });
    } catch (error) {
      console.error('Error deleting inventory:', error);
      toast({
        title: 'Error deleting product',
        status: 'error',
        duration: 2000,
        isClosable: true,
      });
    }
  };
  







  const addItemHandler = async () => {
    try {
      const response = await axios.post(`${backend_url}/api/create`, {
        name,
        category,
        quantity,
        price,
        date
      });
      setName("");
      setCategory("");
      setQuantity("");
      setPrice("");
      setDate("");
      getAllItems();
      toast({
        title: 'Product created',
        status: 'success',
        duration: 2000,
        isClosable: true,
      });
    } catch (error) {
      console.error('Error creating inventory:', error);
      toast({
        title: 'Error creating product',
        status: 'error',
        duration: 2000,
        isClosable: true,
      });
    }
  };

 




  const filteredItems = data ? data.filter(item => {
    const name = item.name || "";
    const category = item.category || "";
    const quantity = item.quantity ? item.quantity.toString() : "";
    const price = item.price ? item.price.toString() : "";
  
    const query = searchQuery || "";
  
    return (
      name.toLowerCase().includes(query.toLowerCase()) ||
      category.toLowerCase().includes(query.toLowerCase()) ||
      quantity.includes(query) ||
      price.includes(query)
    );
  }) : [];
 


  const handleSearchChange = (e) => {
    setSearchQuery(e.target.value);
  };
  
  
  //const backgroundImageUrl = 'https://wallpapercave.com/wp/wp3574701.jpg';



  function formatDate(datetime) {
    const date = new Date(datetime);
    const year = date.getFullYear();
    const month = String(date.getMonth() + 1).padStart(2, '0'); // Months are zero-based in JavaScript
    const day = String(date.getDate()).padStart(2, '0');
    return `${year}-${month}-${day}`;
  }

  return (
    <Container bg={'white'} maxW={'full'} borderWidth={'2px'}
    //bgImage={`url(${backgroundImageUrl})`}

  
    bgSize="cover"
    bgPosition="center"
    h="100vh"  >


    <div className="p-4 d-flex flex-column">
      <Heading className="text-center text-info"  textAlign={'center'} p={4} color={'navy'}>Manage Store</Heading>
{/* <Tabbar/> */}
      <Flex align="center" justify="space-between" className="flex-grow mr-2">


    {/* <Link to="/product_veri">
      <Icon as={MdOutlineNextPlan} color="blue" mr={1} boxSize={'25'} cursor={'pointer'} />
      <Text>Verify/Reject </Text>
      </Link> */}

      
      <FormControl className="m-3">
          <Input
          w={'20%'}
          type="text"
          size={'sm'}
          placeholder="Search..."
          value={searchQuery}
          onChange={handleSearchChange}
          ml='auto'
          borderColor={'blue'}
          _placeholder={{ opacity: 0.8, color: 'navy' }}
          mb={5}
          />
        </FormControl>
      <Popup
        modal
        trigger={
          <Box
          as='button'
          height='30px'
          width="100px"
          lineHeight='1.2'
          transition='all 0.2s cubic-bezier(.08,.52,.52,1)'
          border='1px'
          px='8px'
          borderRadius='2px'
          fontSize='14px'
          fontWeight='semibold'
          borderWidth={'2px'}
          // bg='white'
          borderColor='blue'
          color='blue'
        
          _hover={{ bg: '#ebedf0' }}
          _active={{
            bg: '#dddfe2',
            transform: 'scale(0.98)',
            borderColor: '#bec3c9',
          }}
          _focus={{
            boxShadow:
              '0 0 1px 2px rgba(88, 144, 255, .75), 0 1px 1px rgba(0, 0, 0, .15)',
          }}
        >
          {/* <Button> */}
         Add New

          {/* </Button> */}
        </Box>
          



          
        }
        onClose={clearStateValue}
      >

        {(close) => (
          <>
          <Box p={5} color={'white'} textAlign={'center'} alignItems={'center'} justifyContent={'center'}  flexDirection="column" justifyItems={'center'} borderWidth={'2px'} bg={'gray.700'}>
            <FormControl>
              <FormLabel htmlFor="name" textAlign={'center'}>Part Name</FormLabel>
              <Input
              w={'40%'}
                type="text"
                id="name"
                size={'sm'}
                value={name}
                onChange={(e) => setName(e.target.value)}
              />

<FormLabel htmlFor="price" textAlign={'center'}>Part Number</FormLabel>
              <Input
               w={'40%'}
                type="text"
                id="price"
                size={'sm'}
                value={price}
                mb={4}
                onChange={(e) => setPrice(e.target.value)}
              />

              <FormLabel htmlFor="category" textAlign={'center'}>Category</FormLabel>
              {/* <Input
               w={'40%'}
                type="text"
                id="category"
                size={'sm'}
                value={category}
                onChange={(e) => setCategory(e.target.value)}
              /> */}

              <Select pl={95}  ml={20} id="category" color={'gray'}  w={'57%'} size={'sm'}  value={category} placeholder="Select Category" onChange={(e) => setCategory(e.target.value)}>
<option color={'navy'} value={'RM'}>RM</option>
<option color={'navy'} value={'BOP'}>BOP</option>
<option color={'navy'} value={'Job Work'}>Job Work</option>
<option color={'navy'} value={'Consumeables'}>Consumeables</option>

              </Select>



              <FormLabel htmlFor="quantity" textAlign={'center'}>Quantity</FormLabel>
              <Input
               w={'40%'}
                type="number"
                id="quantity"
                size={'sm'}
                value={quantity}
                onChange={(e) => setQuantity(e.target.value)}
              />
              
              <FormLabel htmlFor="price" textAlign={'center'}>Recieve Date</FormLabel>
              <Input
               w={'40%'}
                type="date"
                id="date"
                size={'sm'}
                value={date}
                mb={4}
                onChange={(e) => setDate(e.target.value)}
              />
            </FormControl>
            <Button
              variant={'outline'}
              w={'20'}
              h={'9'}
              colorScheme="cyan"
              onClick={() => close()}
              mr={4}
            >
              Close
            </Button>
            <Button
             variant={'outline'}
             w={'20'}
             h={'9'}
             colorScheme="blue"
              onClick={addItemHandler}
            >
              Add
            </Button>
            </Box>
          </>
          
        )}
      </Popup>
      </Flex>
      {filteredItems && filteredItems.length!==0?(   
      <Table className="table borderRadius-8 text-center my-5" >
        <Thead bg={'blue.900'}>
          <Tr className="bg-info " >
            <Th color={'white'}>Part Name</Th>
            <Th color={'white'}>Part Number</Th>
            <Th color={'white'}>Category</Th>
            <Th color={'white'}>Quantity</Th>
            <Th color={'white'}>Recieve Date</Th>
            {/* <Th color={'white'}>Image</Th> */}
            <Th color={'white'}>Status</Th>
            <Th color={'white'}>Modify </Th>
            <Th color={'white'}> Delete</Th>
            {/* <Th color={'white'}> Flag</Th> */}
          </Tr>
        </Thead>
        
        <Tbody bg={'blue.800'}>
          {filteredItems&&filteredItems.map((each,index) => (
            <Tr   color={'white'} key={index}>
              <Td color={'white'} fontSize={'13'}>{each.name}</Td>
              <Td color={'white'} fontSize={'13'}>{each.price}</Td>
              <Td color={'white'} fontSize={'13'}>{each.category}</Td>
              <Td color={'white'} fontSize={'13'}>{each.quantity}</Td>
              <Td color={'white'} fontSize={'13'}>{formatDate(each.date)}</Td>
              {/* {image && ( */}
              {/* <Td color={'white'} fontSize={'13'}><Image src={`/uploads/imageName.jpg/${each.image}`}   /></Td> */}
            {/* )} */}
              <Td color={'white'} fontSize={'13'}>{each.status}
  </Td>
              <Td>
                <Popup
                  value={each._id}
                  id={each._id}
                  modal
                  trigger={

                    <ButtonGroup size='sm' isAttached variant='outline' colorScheme="cyan">
  <Button>Modify</Button>
  <IconButton aria-label='Add to friends' icon={<AiFillEdit />} />
</ButtonGroup>
                  //  <Button
                  //  variant="outline"
                  //  w={20}
                  //  h={9}
                  //  border='none'
                  //  colorScheme='cyan'
                  //  leftIcon={<AiFillEdit />}
                  //>
                  //  Update
                  //</Button>
                  }
                  onOpen={()=>getSingleItemHandler(each._id)}
                  onClose={clearStateValue}
                >
                  {(close) => (
                    <>
                      <Box p={5} color={'white'} textAlign={'center'} alignItems={'center'} justifyContent={'center'}  flexDirection="column" justifyItems={'center'} borderWidth={'2px'} bg={'gray.700'}>
            <FormControl>
              <FormLabel htmlFor="name" textAlign={'center'}>Part Name</FormLabel>
              <Input
              w={'40%'}
                type="text"
                id="name"
                size={'sm'}
                value={name}
                onChange={(e) => setName(e.target.value)}
              />

<FormLabel htmlFor="price" textAlign={'center'}>Part Number</FormLabel>
              <Input
               w={'40%'}
                type="text"
                id="price"
                size={'sm'}
                value={price}
                mb={4}
                onChange={(e) => setPrice(e.target.value)}
              />

              <FormLabel htmlFor="category" textAlign={'center'}>Category</FormLabel>
              {/* <Input
               w={'40%'}
                type="text"
                id="category"
                size={'sm'}
                value={category}
                onChange={(e) => setCategory(e.target.value)}
              /> */}

              <Select pl={95}  ml={20} id="category" color={'gray'}  w={'57%'} size={'sm'}  value={category} placeholder="Select Category" onChange={(e) => setCategory(e.target.value)}>
<option color={'navy'} value={'RM'}>RM</option>
<option color={'navy'} value={'BOP'}>BOP</option>
<option color={'navy'} value={'Job Work'}>Job Work</option>
<option color={'navy'} value={'Consumeables'}>Consumeables</option>

              </Select>



              <FormLabel htmlFor="quantity" textAlign={'center'}>Quantity</FormLabel>
              <Input
               w={'40%'}
                type="number"
                id="quantity"
                size={'sm'}
                value={quantity}
                onChange={(e) => setQuantity(e.target.value)}
              />
              
              <FormLabel htmlFor="price" textAlign={'center'}>Recieve Date</FormLabel>
              <Input
               w={'40%'}
                type="date"
                id="date"
                size={'sm'}
                value={date}
                mb={4}
                onChange={(e) => setDate(e.target.value)}
              />
            </FormControl>
                      <Button
                        variant={'outline'}
                        w={'20'}
                        h={'9'}
                        colorScheme="blue"
                        onClick={() => close()}
                        mr={4}
                      >
                        Close
                      </Button>
                      <Button
  variant="outline"
  colorScheme="cyan"
  onClick={() => updateItemHandler(each._id)} 
>
  Update
</Button>
</Box>
                    </>
                  )}
                </Popup>
              </Td>
              <Td>
              <Popup
                  modal
                  trigger={
                    <ButtonGroup size='sm' isAttached variant='outline' colorScheme="cyan">
                    <Button>Delete</Button>
                    <IconButton aria-label='Add to friends' icon={<AiTwotoneDelete />} />
                  </ButtonGroup>
                    
                  }
                >
                  {(close) => (
                    <>
                      <Heading className="text-center text-secondary m-3" >Please confirm if you want to delete This item</Heading>
                      <Button
                       variant={'outline'}
                       w={'20'}
                       h={'9'}
                       colorScheme="cyan"
                        onClick={() => close()}
                        mr={4}
                      >
                        Close
                      </Button>
                      <Button
  variant="outline"
  colorScheme="cyan"
  onClick={() => deleteItemHandler(each._id)} 
>
  Delete
</Button>

                      
                    </>
                  )}
                </Popup>
                
              </Td>
              {/* <Th>
              <ButtonGroup size='sm'  onClick={() => handleFlagItem(each._id)}  isAttached variant='outline' colorScheme="cyan">
  <Button >Flag</Button>
  <IconButton aria-label='Add to friends' icon={<AiFillEdit />} />
</ButtonGroup>
      </Th> */}
              
            </Tr>
          ))}
        </Tbody>
        
      </Table>):<Heading className="text-secondary text-center m-5" color={'GrayText'}>No Items Available</Heading>
      }
    </div>
    </Container>
  );
}

export default Inventory;
