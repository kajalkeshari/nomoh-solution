import React from 'react'
import { Tabs, TabList, TabPanels, Tab, TabPanel, Box } from '@chakra-ui/react'
import Inventory from './Inventory'
import ManageInventory from './ManageInventory'
// import CategoryModules from './CategoryModules'
// import Inventory from './Manageinventory'

const Tabbar = () => {
  return (
    <Box p={6} >
        <Tabs>
  <TabList>
    <Tab fontWeight={'bold'}>Material Recieveing</Tab>
    <Tab fontWeight={'bold'}>Inventory Details</Tab>
    <Tab fontWeight={'bold'}>Rejection Details</Tab>
  </TabList>

  <TabPanels>
    <TabPanel>
      <Inventory/>
    </TabPanel>
    <TabPanel>
    <ManageInventory/>
    </TabPanel>
    <TabPanel>
    <p>Nothing!</p>   </TabPanel>
  </TabPanels>
</Tabs>
    </Box>
  )
}

export default Tabbar