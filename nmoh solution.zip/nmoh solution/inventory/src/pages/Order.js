import React, { useState, useEffect } from "react";
import axios from "axios";
import {
  Box,
  Heading,
  Text,
  Flex,
  Button,
  Container,
  Spinner,
} from "@chakra-ui/react";
const  backend_url=process.env.REACT_APP_URL;

const Order = () => {
  const [orders, setOrders] = useState([]);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    fetchOrders();
  }, []);

  const fetchOrders = async () => {
    try {
      const response = await axios.get(`${backend_url}/api/orders`);
      setOrders(response.data);
      setIsLoading(false);
    } catch (error) {
      console.error("Error fetching orders:", error);
      setIsLoading(false);
    }
  };

  return (
    <Container  p={4} bg={'white'} borderWidth="2px" color={'navy'} h={'100vh'} maxW='100%'>
      <Heading mb={4} fontSize={'24'}>Order Status</Heading>
      {isLoading ? (
        <Flex justify="center">
          <Spinner size="xl" />
        </Flex>
      ) : (
        <Box>
          {orders.map((order) => (
            <Box key={order.id} borderWidth="1px" p={4} mb={4}>
              <Text fontWeight="bold">Order ID: {order.id}</Text>
              <Text>Status: {order.status}</Text>
              <Text>Total Amount: ${order.totalAmount}</Text>
              <Button mt={2} colorScheme="blue">
                Track Order
              </Button>
            </Box>
          ))}
          {orders.length === 0 && (
            <Text color={'gray.900'} fontWeight={'bold'}>No orders found.</Text>
          )}
        </Box>
      )}
    </Container>
  );
};

export default Order;
