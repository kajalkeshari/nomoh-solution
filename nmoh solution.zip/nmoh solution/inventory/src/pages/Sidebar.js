import React, { useState } from "react";
import { Box, Grid, Heading, VStack, Text, AccordionIcon ,GridItem, Flex, Img, Button} from "@chakra-ui/react";

import { Link, Outlet } from "react-router-dom";
import Main from "../Main";
import logo from '../pages/assets/logo.jpg'
import Main2 from "../Main2";
import {LogoutuserAction} from  '../redux/authReducer/action'
import { useDispatch, useSelector } from "react-redux";

function Sidebar() {
  const {isAuthenticated}= useSelector((state)=>state.authReducer)
  const dispatch= useDispatch();
 
 
  const handleLogout = () => {
 dispatch(LogoutuserAction());
 
  }

  return (
    
    <Grid templateColumns="230px 1fr"  >
      {/* Sidebar */}
      <Box bg="white" color="navy" p={6} h={'100vh'}>
        <Img src={logo}/>
        {/* <Heading textAlign="center" fontSize={'18'} mt={5} fontWeight={'800'} color={'blue.700'}>Sales Marketing </Heading> */}
     
        <Box mt={1} fontWeight={'bold'} >
            <VStack align="flex-start" p={2} > 
            <Link to={'/'}>
         <Text fontSize={'15'} fontWeight={'700'}> Material Receiveing</Text>
            </Link> 
            <Link to={'/product_verify'}>
          <Text fontSize={'15'} fontWeight={'700'}>Incoming Quality</Text>
            </Link>   



            <Link to={'/manage_inventory'}>
          <Text fontSize={'15'} fontWeight={'700'}>Inventory Details</Text>
            </Link>
            <Link to={'/reject_inventory'}>
          <Text fontSize={'15'} fontWeight={'700'}>Rejection Details</Text>
            </Link>
            <Link to={'/manage_department'}>
          <Text fontSize={'15'} fontWeight={'700'}>Department</Text>
            </Link>
            <Box>
            {isAuthenticated && isAuthenticated ? 
        <Box as="button" onClick={handleLogout}> 
        <Text fontSize={'15'} fontWeight={'700'}>Logout</Text>
        </Box>
        :''}
        </Box>


{/*          
        <Link to={'/satisfy_customer'}>
         <Text fontSize={'15'} fontWeight={'700'}>Satisfaction</Text> 
        </Link>
        <Link to={'/order'}>
          <Text fontSize={'15'} fontWeight={'700'}>Order </Text>
        </Link> */}
          
          </VStack>

        </Box>
      </Box>

      {/* Main Content */}
      <Flex >
     <Main2/>
       
        <Outlet/>
    </Flex>
    </Grid>
  );
}

export default Sidebar;


