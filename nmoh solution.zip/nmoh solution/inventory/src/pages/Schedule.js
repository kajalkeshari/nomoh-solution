import React, { useState, useEffect } from "react";
import Calendar from "react-calendar";
import "../pages/Schedule.css";
import {
  Box,
  Heading,
  Text,
  Icon, Button,
  useDisclosure,
  Modal,
  ModalOverlay,
  ModalContent,
  ModalHeader,
  ModalCloseButton,
  ModalBody,
  ModalFooter,
  HStack,
} from "@chakra-ui/react";
import axios from "axios";
import { FaCalendarCheck } from "react-icons/fa";
const  backend_url=process.env.REACT_APP_URL;

const Schedule = () => {
  const [interestedCustomers, setInterestedCustomers] = useState([]);
  // const [notInterestedCustomers, setNotInterestedCustomers] = useState([]);
  const [selectedDate, setSelectedDate] = useState(new Date());
  const { isOpen, onOpen, onClose } = useDisclosure();
  const [selectedCustomer, setSelectedCustomer] = useState(null);
  const [hoveredDate, setHoveredDate] = useState(null);

  useEffect(() => {
    fetchCustomers();
  }, []);

  const fetchCustomers = async () => {
    try {
      const response = await axios.get(
        `${backend_url}/api/read_customers`
      );
      const data = response.data;
      setInterestedCustomers(
        data.filter(
          (customer) =>
            customer.date === "Interested" &&
            new Date(customer.scheduledate) >= new Date()
        )
      );
    } catch (error) {
      console.error("Error fetching customers:", error);
    }
  };

  const scheduledDates = interestedCustomers.reduce((acc, customer) => {
    const date = new Date(customer.scheduledate);
    const monthYear = date.toLocaleDateString("en-US", {
      month: "long",
      year: "numeric",
    });
    if (!acc[monthYear]) {
      acc[monthYear] = [];
    }
    acc[monthYear].push(date.toLocaleDateString());
    return acc;
  }, {});

  const handleDateClick = (date) => {
    const formattedDate = date.toLocaleDateString();
    const customer = interestedCustomers.find((customer) => {
      const customerDate = new Date(customer.scheduledate).toLocaleDateString();
      return customerDate === formattedDate;
    });
    setSelectedCustomer(customer);
    onOpen();
  };



  const renderThumbnail = (date) => {
    // Assuming you have thumbnail images named according to the date
    const thumbnailPath = `path/to/thumbnails/${date}.jpg`; // Update the path to your thumbnail images
    return (
      <Box bg={'orange'}>{ }</Box>
    );
  };

  const tileContent = ({ date }) => {
    const formattedDate = date.toLocaleDateString();
    const isDateScheduled = Object.values(scheduledDates).some(dates => dates.includes(formattedDate));

    return (
      <div
        onClick={() => handleDateClick(date)}
        style={{ position: "relative", width: "100%", height: "100%" }}
      >
        {isDateScheduled && (
          <>
            {renderThumbnail(formattedDate)}
            <FaCalendarCheck
              style={{
                position: "right",
                // top: "10%",
                // left: "50%",
                transform: "translate(-50%, -50%)",
                color: "orange",
                fontSize: 15,
              }}
            />
          </>
        )}
      </div>
    );
  };


  function formatDate(datetime) {
    const date = new Date(datetime);
    const year = date.getFullYear();
    const month = String(date.getMonth() + 1).padStart(2, '0'); // Months are zero-based in JavaScript
    const day = String(date.getDate()).padStart(2, '0');
    return `${year}-${month}-${day}`;
  }


  return (
    <Box  w={"100%"} p={4} bg="white" color={"navy"} borderWidth={'2px'}>
      <Box w={{ base: "70%", md: "80%" }} >
        <Heading fontSize={{ base: "24px", md: "25px" }} mb={4}>
          Manage Schedule
        </Heading>
        <HStack flexDirection={'row'}  p={5}>
        
          <Box  p={4} bg={"navy"}  maxW={"50%"} borderRadius={8} borderWidth={"2px"} color={"white"}>
            <Text fontSize="15" textAlign={"center"} fontWeight="bold">
              Schedule Dates
            </Text>
            {Object.entries(scheduledDates).map(([monthYear, dates]) => (
              <Box key={monthYear} mt={3}>
                <Text fontSize="13" textAlign={"center"} fontWeight="bold">
                  {monthYear}
                </Text>
                {dates.map((date, index) => (
                  <Text
                    key={index}
                    fontSize={'11'}
                    cursor="pointer"
                    bg={hoveredDate === date ? "orange" : ""}
                    textAlign={"center"}
                    onMouseEnter={() => {
                      console.log("Mouse enter:", date);
                      setHoveredDate(date);
                    }}
                    onMouseLeave={() => setHoveredDate(null)}
                    // onClick={() => handleDateClick(new Date(date))}
                    mt={2}
                  >
                    {date}
                  </Text>
                ))}
              </Box>
            ))}
          </Box>


          <Box p={4}  justifyContent={"right"}>
        <Calendar onChange={setSelectedDate} value={selectedDate} tileContent={tileContent} onClickDay={handleDateClick} />
       </Box>


          </HStack>
       </Box>
    

      

       <Modal isOpen={isOpen} onClose={onClose}>
        <ModalOverlay />
        <ModalContent bg={"gray.300"}>
          <ModalHeader fontWeight={"bold"} textAlign={"center"} color={"blue.900"}>
            Customer Details
          </ModalHeader>
          <ModalCloseButton />
          <ModalBody>
            {selectedCustomer && (
              <Box textAlign={"left"} fontWeight={"500"} color={"navy"}>
                <Text>Name: {selectedCustomer.customerName}</Text>
                <Text>Email: {selectedCustomer.email}</Text>
                <Text>Meeting Date: {formatDate(selectedCustomer.quotationSubmissionDate)}</Text>
                <Text>Contact: {selectedCustomer.customerNumber}</Text>
                <Text>Business Category: {selectedCustomer.businessCategory}</Text>
                <Text>Company Name: {selectedCustomer.companyName}</Text>
                <Text>City: {selectedCustomer.city}</Text>
                <Text>State: {selectedCustomer.state}</Text>
              </Box>
            )}
          </ModalBody>
          <ModalFooter>
            <Button colorScheme="blue" onClick={onClose}>
              Close
            </Button>
          </ModalFooter>
        </ModalContent>
       </Modal>
    
       
    </Box>
  );
};

export default Schedule;
