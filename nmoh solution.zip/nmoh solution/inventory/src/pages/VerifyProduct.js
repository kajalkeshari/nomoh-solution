import React, { useEffect, useState } from 'react';
import axios from 'axios';
import {
  Table,
  Thead,
  Tbody,
  Tr,
  Th,
  Td,
  Button,
  Box,
  Flex,
  Heading,Select,Input
} from "@chakra-ui/react";
// import Inventory from './Manageinventory';
const  backend_url=process.env.REACT_APP_URL;

const VerifyProduct = () => {
  const [data, setData] = useState([]);
  const [selectedProductId, setSelectedProductId] = useState('');
  const [selectedAction, setSelectedAction] = useState('');
  const [image, setImage] = useState(null);

  useEffect(() => {
    fetchData();
  }, []);

  const fetchData = async () => {
    try {
      const response = await axios.get(`${backend_url}/api/read`);
      
      setData(response.data);
     
      // console.log("data:", response.data);
    } catch (error) {
      console.error('Error fetching data:', error);
     
    }
  };

 

const handleActionSelect = (e, productId) => {
  setSelectedAction(e.target.value); 
  setSelectedProductId(productId); 
};




 
 const handleOK = async (productId) => {
  try {
    if (!selectedAction) {
      console.error('Please select an action');
      return;
    }

    const response = await axios.put(`${backend_url}/api/${selectedAction}/${productId}`);
    console.log(response.data); 
   
    fetchData();
  } catch (error) {
    console.error('Error updating product status:', error);
  }
};


const handleFlagItem = async (id) => {
  try {
    
    await axios.post(`${backend_url}/api/flag/${id}`);
    alert('Item flagged successfully!');
  } catch (error) {
    console.error('Error flagging item:', error);
    alert('An error occurred while flagging the item. Please try again later.');
  }
};


const handleImageUpload = async (e, id) => {
  const file = e.target.files[0];
  const formData = new FormData();
  formData.append('image', file);

  try {
    await axios.post(`${backend_url}/api/upload`, formData);
    alert('Image uploaded successfully!');
  } catch (error) {
    console.error('Error uploading image:', error);
    alert('An error occurred while uploading the image. Please try again later.');
  }
};

function formatDate(datetime) {
  const date = new Date(datetime);
  const year = date.getFullYear();
  const month = String(date.getMonth() + 1).padStart(2, '0'); // Months are zero-based in JavaScript
  const day = String(date.getDate()).padStart(2, '0');
  return `${year}-${month}-${day}`;
}

  return (
    <Box p={4} h={'100vh'} borderWidth={'2px'} w={'100%'}>
      <Heading textAlign={'center'} p={4} color={'navy'}>Incoming Quality Management System</Heading>
      <Table className="table text-center my-5">
        <Thead bg={'blue.800'} fontSize={'10'}>
          <Tr>
            <Th color={'white'} fontSize={'11'}> Part Name</Th>
            <Th color={'white'} fontSize={'11'}> Part Number</Th>
            <Th color={'white'} fontSize={'11'}>Category</Th>
            <Th color={'white'} fontSize={'11'}>Quantity</Th>
            <Th color={'white'} fontSize={'11'}>Recieve Date</Th>
            <Th color={'white'} fontSize={'11'}>Judgement</Th>
            {/* <Th color={'whi fontSize={'11'}te'}>Image Upload</Th> */}
            <Th color={'white'} fontSize={'11'}>Action</Th>
            <Th color={'white'} fontSize={'11'}>Flag</Th>
            {/* <Th color={'white'}>Action</Th> */}
          </Tr>
        </Thead>
        <Tbody bg={'blue.700'} color={'white'} fontSize={'12'}>

          {data && data.map((item, index) => (
            
            <Tr key={index}>
              <Td >{item.name}</Td>
              <Td>{item.price}</Td>
              <Td>{item.category}</Td>
              <Td>{item.quantity}</Td>
              <Td>{formatDate(item.date)}</Td>
              <Td>{item.status}</Td>
              {/* <Td> */}
              {/* <Input type="file" size={'xs'} name='image' border={'none'} onChange={(e) => handleImageUpload(e, item._id)} /> */}
              {/* </Td> */}
              <Td>
              <Flex align="center">
                <Select
                  size={'sm'}
                  color={'gray.200'}
                  placeholder="Select action"
                  onChange={(e) => handleActionSelect(e, item._id)}
                  value={selectedAction}
               
                >
                  <option value="verify">Verify</option>
                  <option value="reject">Reject</option>
                </Select>
                {selectedAction && ( 
                  <Button
                    ml={2}
                    size={'sm'}
                    colorScheme="teal"
                    onClick={() => handleOK(item._id)}
                   
                  >
                    OK
                  </Button>

                  
                )}



  {/* <IconButton aria-label='Add to friends' icon={<AiFillEdit />} /> */}

              </Flex>
              </Td>
              <Td> <Button size='sm' onClick={() => handleFlagItem(item._id)} variant='outline' colorScheme="cyan">Flag</Button></Td>
              {/* <Td> */}
                {/* <Inventory image={image}/> */}
              {/* </Td> */}
            </Tr>
          ))}
        </Tbody>
      </Table>
    </Box>
  );
};

export default VerifyProduct;
