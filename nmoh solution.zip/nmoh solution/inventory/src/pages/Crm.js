import React, { useState, useEffect } from "react";
import axios from "axios";
import { EditIcon, DeleteIcon } from "@chakra-ui/icons";
import { Button,Image, Text, Heading, Box, Input, Flex, HStack , Table,Drawer,FormLabel, DrawerOverlay, DrawerContent, DrawerCloseButton, DrawerHeader, DrawerBody, Thead, Tbody, Tr, Th, Select, Img, Td, Center, DrawerFooter, Divider, Stack  } from "@chakra-ui/react";
const  backend_url=process.env.REACT_APP_URL;


const CRM = ({imageName}) => {
  const [customers, setCustomers] = useState([]);
  const [customerFormData, setCustomerFormData] = useState("");
  const [interestedCustomers, setInterestedCustomers] = useState([]);
  const [notInterestedCustomers, setNotInterestedCustomers] = useState([]);
  const [isDrawerOpen, setIsDrawerOpen] = useState(false);
  const [selectedCustomer, setSelectedCustomer] = useState(null);
  const [isEditMode, setIsEditMode] = useState(false);
  const [imageFiles, setImageFiles] = useState([]);


  useEffect(() => {
    // Fetch image filenames from the server
    axios.get(`${backend_url}/api/find/image`)
      .then(response => {
        setImageFiles(response.data.files);
      })
      .catch(error => console.error('Error fetching images:', error));
  }, []); // Empty dependency array ensures this effect runs only once on component mount

  


  useEffect(() => {
    fetchCustomers();
  }, []);

  const fetchCustomers = async () => {
    try {
      const response = await axios.get(`${backend_url}/api/read_customers`);
      const data = response.data;
      setCustomers(data);

      const interested = data.filter((customer) => customer.date === "Interested");
      const notInterested = data.filter((customer) => customer.date === "Not Interested");

      const interestedWithDate = interested.map(customer => ({ ...customer, date: 'Interested' }));

      setInterestedCustomers(interestedWithDate);
      setNotInterestedCustomers(notInterested);
    } catch (error) {
      console.error("Error fetching customers:", error);
    }
  };

 
  

  const deleteCustomer = async (customerId) => {
    try {
      if (window.confirm("Are you sure you want to delete this customer?")) {
        await axios.delete(`${backend_url}/api/delete_customer/${customerId}`);
        alert("Customer deleted successfully.");
        await fetchCustomers();
      }
    } catch (error) {
      console.error("Error deleting customer:", error);
    }
  };

  const handleImageInputChange = (e) => {
    setCustomerFormData({
      ...customerFormData,
      image: e.target.files[0], // Save the selected image file
    });
  };


  // const handleInputChange = (e) => {
  //   setCustomerFormData({ ...customerFormData, [e.target.name]: e.target.value });
  // };

  const handleCustomerInputChange = (e) => {
    setCustomerFormData({ ...customerFormData, [e.target.name]: e.target.value });
  };





  const AddCustomer = async () => {
    try {
      if (!customerFormData) {
        alert("Please fill in all required fields.");
        return;
      }


      // Create a FormData object to handle multipart/form-data
      const formData = new FormData();
      formData.append('date', customerFormData.date);
      formData.append('srno', customerFormData.srno);
      formData.append('companyName', customerFormData.companyName);
      
      formData.append('customerName', customerFormData.customerName);
      formData.append('scheduledate', customerFormData.scheduledate);
      formData.append('customerNumber', customerFormData.customerNumber);
      formData.append('email', customerFormData.email);
      formData.append('city', customerFormData.city);
      formData.append('office', customerFormData.office);
      formData.append('state', customerFormData.state);
      formData.append('businessCategory', customerFormData.businessCategory);
      formData.append('requiredItem', customerFormData.requiredItem);
      formData.append('requiredQuantity', customerFormData.requiredQuantity);
      formData.append('productSpecific', customerFormData.productSpecific);
      formData.append('orderValue', customerFormData.orderValue);
      formData.append('feasibility', customerFormData.feasibility);
      formData.append('quotationSubmissionDate', customerFormData.quotationSubmissionDate);
      formData.append('followingResult', customerFormData.followingResult);
      formData.append('image', customerFormData.image);



 
      // Send POST request with FormData
      const response = await axios.post(`${backend_url}/api/add_customer`, formData, {
        headers: {
          'Content-Type': 'multipart/form-data' 
        }
      });

      const newCustomer = response.data;
      await fetchCustomers();
      
      setCustomers([...customers, newCustomer]);
      setCustomerFormData({date: "",
      srno: "",
      companyName: "",
      customerName: "",
      scheduledate: "",
      customerNumber: "",
      email: "",
      city: "",
      office: "",
      state: "",
      businessCategory: "",
      requiredItem: "",
      requiredQuantity: "",
      productSpecific: "",
      orderValue: "",
      feasibility: "",
      quotationSubmissionDate: "",
      followingResult: "",
      image: null });
      

      alert("Customer added successfully.");
    } catch (error) {
      console.error("Error adding customer:", error);
      console.log(error);
    }
  };


  const handleEditCustomer = (customer) => {
    setSelectedCustomer(customer);
    setCustomerFormData(customer);
    setIsEditMode(true);
    setIsDrawerOpen(true);
  };




  const handleUpdateCustomer = async () => {
    try {
      // Send update request to the server
      const response = await axios.put(`${backend_url}/api/update_customer/${selectedCustomer._id}`, customerFormData);
      console.log(response.data);
      alert("Customer updated successfully.");
      await fetchCustomers();
      setIsDrawerOpen(false);
      setSelectedCustomer(null);
      setCustomerFormData({date: "",
      srno: "",
      companyName: "",
      customerName: "",
      scheduledate: "",
      customerNumber: "",
      email: "",
      city: "",
      office: "",
      state: "",
      businessCategory: "",
      requiredItem: "",
      requiredQuantity: "",
      productSpecific: "",
      orderValue: "",
      feasibility: "",
      quotationSubmissionDate: "",
      followingResult: "",
      image: null });
    } catch (error) {
      console.error("Error updating customer:", error);
    }
  };

  function formatDate(datetime) {
    const date = new Date(datetime);
    const year = date.getFullYear();
    const month = String(date.getMonth() + 1).padStart(2, '0'); // Months are zero-based in JavaScript
    const day = String(date.getDate()).padStart(2, '0');
    return `${year}-${month}-${day}`;
  }
  

  return (
      <Box borderWidth="2px" p={4} bg="white" color={'navy'} >
        {/* <Flex justifyContent="space-between" alignItems="center"> */}
        <Box w={{ base: "70%", md: "80%" }} >
          <Heading fontSize={{ base: '24px', md: '25px' }} mb={4}>Manage Customers</Heading>




          <Flex direction="row" flexWrap="wrap" p={4}>
            {interestedCustomers.map((customer, index) => (
              <Box
                key={index}
                borderWidth="1px"
                bg="navy"
                color="white"
                p={2}
                borderRadius={8}
                mb={4}
                mr={4} // Add margin to create space between boxes
              >
                <Text fontSize="11">
                  <b>Name:</b> {customer.customerName}
                </Text>
              
                <Text fontSize="11">
                  <b>City:</b> {customer.city}
                </Text>
          
                <Text fontSize="11">
                  <b>Date:</b> {formatDate(customer.scheduledate)}
                </Text>
              </Box>
            ))}
          </Flex>





          <HStack  spacing={100} p={4} >

            <Box bg={'blue.100'} w={'65%'} p={2} borderRadius={5} borderWidth={'2px'} borderColor={'navy'}>
              <Box bg='navy' color={'white'} mb={2} fontWeight={'bold'} textAlign={'center'} p={1} fontSize={'14'} borderRadius={4}>Customer Form Details</Box>
              <form action="/uploads/:imageName" method="post"  enctype="multipart/form-data">
                <HStack  p={2}   >
<Stack  alignItems={'center'} spacing={0}>
                <FormLabel fontSize={'13'}>Company Name</FormLabel>
                  <Input
                    type="text"
                    name="companyName"
                    value={customerFormData.companyName}
                    onChange={handleCustomerInputChange}
                    size={'sm'}
              
                    borderColor={'navy'}
                    color={'navy'}
                    // placeholder="Company Name"
                  />
</Stack >

                  {/* <Box textAlign={"center"} flex={1}> */}
                  {/* <HStack  p={2}> */}
                  <Stack  alignItems={'center'} spacing={0}>
                  <FormLabel fontSize={'13'}>City</FormLabel>
                  <Input
                    type="text"
                    name="office"
                    borderColor={'navy'}
                    value={customerFormData.office}
                    size={'sm'}
                    // placeholder="City"
                    onChange={handleCustomerInputChange}
                  />
                  </Stack >
                  <Stack  alignItems={'center'} spacing={0}>
                  <FormLabel fontSize={'13'}>District</FormLabel>
                  <Input
                    type="text"
                    name="city"
                    size={'sm'}
                    // placeholder="District"
                    borderColor={'navy'}
                    value={customerFormData.city }
                    onChange={handleCustomerInputChange}
                  />
                   </Stack >
                   <Stack  alignItems={'center'} spacing={0}>
                   <FormLabel fontSize={'13'}>State</FormLabel>
                  <Input
                    type="text"
                    name="state"
                    // placeholder="State"
                    borderColor={'navy'}
                    size={'sm'}
                    value={customerFormData.state}
                    onChange={handleCustomerInputChange}
                      
                  />
                  </Stack >
                  {/* </HStack > */}
                  {/* </Box> */}


                </HStack >

                <HStack  p={2}>
                <Stack  alignItems={'center'} spacing={0}>
                <FormLabel fontSize={'13'}>Customer Name</FormLabel>
                  <Input
                    type="text"
                    name="customerName"
                    borderColor={'navy'}
                    // placeholder="Customer Name"
                    size={'sm'}
                    value={customerFormData.customerName}
                    onChange={handleCustomerInputChange}
                  />
                      </Stack >

                      <Stack  alignItems={'center'} spacing={0}>
                      <FormLabel fontSize={'13'}>Contact Number</FormLabel>
                  <Input
                    type="number"
                    name="customerNumber"
                    borderColor={'navy'}
                    // placeholder="Contact Number"
                    size={'sm'}
                    value={customerFormData.customerNumber}
                    onChange={handleCustomerInputChange}
                  />
                   </Stack >
                   <Stack  alignItems={'center'} spacing={0}>
                   <FormLabel fontSize={'13'}>Email</FormLabel>
                  <Input
                    type="email"
                    name="email"
                    // placeholder="Email"
                    borderColor={'navy'}
                    size={'sm'}
                    value={customerFormData.email}
                    onChange={handleCustomerInputChange}
                  />
                      </Stack >
                      <Stack  alignItems={'center'} spacing={0}>
                   <FormLabel fontSize={'13'}>Business Category</FormLabel>

                      <Input
                    type="text"
                    name="businessCategory"
                    // placeholder="Business Category"
                    borderColor={'navy'}
                    size={'sm'}
                    value={customerFormData.businessCategory}
                    onChange={handleCustomerInputChange}
                  />
                   </Stack >
                </HStack >
                <HStack  p={2}>
                <Stack  alignItems={'center'} spacing={0}>
                   <FormLabel fontSize={'13'}>Required Item</FormLabel>
                  <Input
                    type="text"
                    name="requiredItem"
                    // placeholder="Required Item"
                    borderColor={'navy'}
                    size={'sm'}
                    value={customerFormData.requiredItem}
                    onChange={handleCustomerInputChange}
                  />
                   </Stack >

                   <Stack  alignItems={'center'} spacing={0}>
                   <FormLabel fontSize={'13'}>Required Quantity</FormLabel>

                  <Input
                    type="number"
                    name="requiredQuantity"
                    // placeholder="Required Quantity"
                    borderColor={'navy'}
                    size={'sm'}
                    value={customerFormData.requiredQuantity}
                    onChange={handleCustomerInputChange}
                  />
                      </Stack >

                      <Stack  alignItems={'center'} spacing={0}>
                   <FormLabel fontSize={'13'}>Product Specification</FormLabel>

                      <Input
                    type="text"
                    name="productSpecific"
                    borderColor={'navy'}
                    // placeholder="Product Specification"
                    size={'sm'}
                    value={customerFormData.productSpecific}
                    onChange={handleCustomerInputChange}
                  />
                    </Stack >
                    {/* <Stack  alignItems={'center'} spacing={0}>
                   <FormLabel>Location</FormLabel>
                    <Input
                    type="text"
                    name="orderValue"
                    // placeholder="Location"
                    borderColor={'navy'}
                    size={'sm'}
                    value={customerFormData.orderValue}
                    onChange={handleCustomerInputChange}
                  />
                  </Stack > */}

                  <Stack  alignItems={'center'} spacing={0}>
                   <FormLabel fontSize={'13'}>Feasible/Not Feasible</FormLabel>
                    
                   <Select
                    name="feasibility"
                    value={customerFormData.feasibility}
                    onChange={handleCustomerInputChange}
                    size={'sm'}
                    w={180}
                    borderColor={'navy'}
                    placeholder="--Select--"
                  >
                    <option value="Feasible">Feasible</option>
                    <option value="Not feasible">Not Feasible</option>
                  </Select>
                     </Stack >


                </HStack >
                <HStack  p={2}>
               
                  
                     <Stack  alignItems={'center'} spacing={0}>
                  <FormLabel fontSize={'13'}>Meeting Date</FormLabel>
                  <Input
                    type="date"
                    borderColor={'navy'}
                    color={'gray.500'}
                    name="quotationSubmissionDate"
                    w={180}
                    // placeholder="Meeting Date"
                    size={'sm'}
                    value={customerFormData.quotationSubmissionDate}
                    onChange={handleCustomerInputChange}
                  />
                  </Stack >
                  <Stack  alignItems={'center'} spacing={0}>
                    <FormLabel fontSize={'13'}>Schedule Date</FormLabel>
                  <Input
                    type="date"
                    borderColor={'navy'}
                    color={'gray.500'}
                    name="scheduledate"
                    w={190}
                    // placeholder="Schedule Date"
                    size={'sm'}
                    value={customerFormData.scheduledate}
                    onChange={handleCustomerInputChange}
                  />
                  </Stack >

                  <Stack  alignItems={'center'} spacing={0}>
                   <FormLabel fontSize={'13'}>Discussion Details</FormLabel>
                  <Input
                    type="text"
                    name="followingResult"
                    borderColor={'navy'}
                    // placeholder="Discussion Details"
                    size={'sm'}
                    value={customerFormData.followingResult}
                    onChange={handleCustomerInputChange}
                  />
 </Stack >
                   <Stack  alignItems={'center'} spacing={0}>
                   <FormLabel fontSize={'13'}>Location</FormLabel>
                    <Input
                    type="text"
                    name="orderValue"
                    // placeholder="Location"
                    borderColor={'navy'}
                    size={'sm'}
                    value={customerFormData.orderValue}
                    onChange={handleCustomerInputChange}
                  />
                  </Stack >

 
 <Stack  alignItems={'center'} spacing={0} mt={8}>
                  {/* <Input
                    type="file"
                    border={'none'}
                    name="image"
                    borderColor={'navy'}
                    size={'sm'}
                    onChange={handleImageInputChange}
                  /> */}
                   </Stack>
 
                </HStack >
                <HStack  p={2}>


                  



                <Stack  alignItems={'center'} spacing={0}>
 <Select
                    name="date"
                    size={'sm'}
                    borderColor={'navy'}
                    value={customerFormData.date}
                    w={180}
                    onChange={handleCustomerInputChange}
                    placeholder="--Select--"
                  >
                    <option value="Interested">Interested</option>
                    <option value="Not Interested">Not Interested</option>
                  </Select>
                  </Stack >


                </HStack >
                <Flex justifyContent={'flex-end'} >
                <Button onClick={handleUpdateCustomer} variant="outline"   borderRadius={2}
                    fontWeight="bold"
                    h={9}
                    fontSize={'13'}
                    borderWidth="2px" colorScheme="blue" mr={4} >
              Update
            </Button>

                  <Button

                    variant="outline"
                    borderWidth="2px"
                    colorScheme="teal"
                    // color={'white'}
                    borderRadius={2}
                    fontWeight="bold"
                    h={9}
                    fontSize={'13'}
                    onClick={AddCustomer}

                  >
                    Add Customer
                  </Button>

                 
                </Flex>
              </form>

            </Box>
          </HStack >


        </Box>

        {/* </Flex> */}





        {/* DataTable for Interested Customers */}
        <Box p={4} >
          <Heading fontSize={'16'} color={'navy'} fontWeight={'900'} bg={'blue.100'} borderRadius={4} p={2}>Interested Customer Lead</Heading>
          <Box overflowX="auto" w={'62%'} borderRadius={8} mt={4}>
            <Table variant="striped" colorScheme="blue" display={'block'} size='sm'  >
              <Thead bg={'navy'}>
                <Tr >
                  {/* <Th fontSize={'11'} color={'gray.200'}>Sr. No.</Th> */}
                  {/* <Th fontSize={'11'} textAlign={'center'} color={'gray.200'}>Image</Th> */}
                  <Th fontSize={'11'} textAlign={'center'} color={'gray.200'}>Follow Update</Th>
                  <Th fontSize={'11'} textAlign={'center'} color={'gray.200'}>Company Name</Th>
                  <Th fontSize={'11'} textAlign={'center'} color={'gray.200'}>City</Th>
                  <Th fontSize={'11'} textAlign={'center'} color={'gray.200'}>District</Th>
                  <Th fontSize={'11'} textAlign={'center'} color={'gray.200'}>State</Th>
                  <Th fontSize={'11'} textAlign={'center'} color={'gray.200'}>Customer Name</Th>
                  <Th fontSize={'11'} textAlign={'center'} color={'gray.200'}>Customer Number</Th>
                  <Th fontSize={'11'} textAlign={'center'} color={'gray.200'}>Email</Th>
                  <Th fontSize={'11'} textAlign={'center'} color={'gray.200'}>Business Category</Th>
                  <Th fontSize={'11'} textAlign={'center'} color={'gray.200'}>Required Item</Th>
                  <Th fontSize={'11'} textAlign={'center'} color={'gray.200'}>Required Quantity</Th>
                  <Th fontSize={'11'} textAlign={'center'} color={'gray.200'}>Product Specific</Th>
                  <Th fontSize={'11'} textAlign={'center'} color={'gray.200'}>Location</Th>
                  <Th fontSize={'11'} textAlign={'center'} color={'gray.200'}>Feasible / Not Feasible</Th>
                  <Th fontSize={'11'} textAlign={'center'} color={'gray.200'}>Meeting Date</Th>
                  <Th fontSize={'11'} textAlign={'center'} color={'gray.200'}>Schedule Date</Th>
                  <Th fontSize={'11'} textAlign={'center'} color={'gray.200'}>Following Result</Th>
                  {/* <Th fontSize={'11'} textAlign={'center'} color={'gray.200'}>Status</Th> */}
                  <Th fontSize={'11'} textAlign={'center'} color={'gray.200'}>Actions</Th>
                </Tr>
              </Thead>
              <Tbody>
                {interestedCustomers.map((customer, index) => (
                  
                  <Tr key={index}>
                    {/* <Td fontSize={'11'}>{customer.srno}</Td> */}
                 
                    
         {/* <Td> 
         {imageFiles.map((filename, index) => (
        <img key={index} src={`/uploads/${filename}`} 
        // alt={filename}
         style={{ width: '50px', height: '50px' }} /> 
        ))}</Td> */}
      

                    <Td fontSize={'11'} textAlign={'center'}>{customer.date}</Td>
                    <Td fontSize={'11'} textAlign={'center'}>{customer.companyName}</Td>
                    <Td fontSize={'11'} textAlign={'center'}>{customer.office}</Td>
                    <Td fontSize={'11'} textAlign={'center'}> {customer.city}</Td>
                    <Td fontSize={'11'} textAlign={'center'}>  {customer.state}</Td>
                   <Td fontSize={'11'} textAlign={'center'}>{customer.customerName}</Td>
                    <Td fontSize={'11'} textAlign={'center'}>{customer.customerNumber}</Td>
                    <Td fontSize={'11'} textAlign={'center'}>{customer.email}</Td>
                    <Td fontSize={'11'} textAlign={'center'}>{customer.businessCategory}</Td>
                    <Td fontSize={'11'} textAlign={'center'}>{customer.requiredItem}</Td>
                    <Td fontSize={'11'} textAlign={'center'}>{customer.requiredQuantity}</Td>
                    <Td fontSize={'11'} textAlign={'center'}>{customer.productSpecific}</Td>
                    <Td fontSize={'11'} textAlign={'center'}>{customer.orderValue}</Td>
                    <Td fontSize={'11'} textAlign={'center'}>{customer.feasibility}</Td>
                    <Td fontSize={'11'} textAlign={'center'}>{formatDate(customer.quotationSubmissionDate)}</Td>
                    <Td fontSize={'11'} textAlign={'center'}>{formatDate(customer.scheduledate)}</Td>
                    <Td fontSize={'11'} textAlign={'center'}>{customer.followingResult}</Td>
                    {/* <Td fontSize={'11'} textAlign={'center'}>{customer.status}</Td> */}
                    <Td>
                      <Flex justifyContent="center">
                        <Button colorScheme="blue" h={6} w={5} variant="outline" onClick={() => handleEditCustomer(customer)} borderWidth="2px" mr={1}
                      
                    >
                      <EditIcon />
                    </Button>
                        <Button colorScheme="blue" h={6} w={5} variant="outline" borderWidth="2px"
                          onClick={() => deleteCustomer(customer._id)}
                        >
                          <DeleteIcon />
                        </Button>
                      </Flex>
                    </Td>
                  </Tr>
                ))}
              </Tbody>
            </Table>
          </Box>
        </Box>








            






        <Box p={4}>
          <Heading fontSize={'16'} color={'navy'} fontWeight={'900'} bg={'blue.100'} borderRadius={4} p={2}>Not Interested Customer Lead</Heading>
          <Box overflowX="auto" w={'62%'} borderRadius={8} mt={4}>
            <Table variant="striped" colorScheme="blue" size='sm' >
              <Thead bg={'navy'}>
                <Tr>
                  {/* <Th fontSize={'11'} color={'gray.200'}>Sr. No.</Th> */}
                  {/* <Th fontSize={'11'} textAlign={'center'} color={'gray.200'}>Image</Th> */}
                  <Th fontSize={'11'} textAlign={'center'} color={'gray.200'}>Follow Update</Th>
                  <Th fontSize={'11'} textAlign={'center'} color={'gray.200'}>Company Name</Th>
                  <Th fontSize={'11'} textAlign={'center'} color={'gray.200'}>City</Th>
                  <Th fontSize={'11'} textAlign={'center'} color={'gray.200'}>District</Th>
                  <Th fontSize={'11'} textAlign={'center'} color={'gray.200'}>State</Th>
                  <Th fontSize={'11'} textAlign={'center'} color={'gray.200'}>Customer Name</Th>
                  <Th fontSize={'11'} textAlign={'center'} color={'gray.200'}>Customer Number</Th>
                  <Th fontSize={'11'} textAlign={'center'} color={'gray.200'}>Email</Th>
                  <Th fontSize={'11'} textAlign={'center'} color={'gray.200'}>Business Category</Th>
                  <Th fontSize={'11'} textAlign={'center'} color={'gray.200'}>Required Item</Th>
                  <Th fontSize={'11'} textAlign={'center'} color={'gray.200'}>Required Quantity</Th>
                  <Th fontSize={'11'} textAlign={'center'} color={'gray.200'}>Product Specific</Th>
                  <Th fontSize={'11'} textAlign={'center'} color={'gray.200'}>Location</Th>
                  <Th fontSize={'11'} textAlign={'center'} color={'gray.200'}>Feasible / Not Feasible</Th>
                  <Th fontSize={'11'} textAlign={'center'} color={'gray.200'}>Meeting Date</Th>
                  <Th fontSize={'11'} textAlign={'center'} color={'gray.200'}>Schedule Date</Th>
                  <Th fontSize={'11'} textAlign={'center'} color={'gray.200'}>Following Result</Th>
                  {/* <Th fontSize={'11'} textAlign={'center'} color={'gray.200'}>Status</Th> */}
                  <Th fontSize={'11'} textAlign={'center'} color={'gray.200'}>Actions</Th>
                </Tr>
              </Thead>
              <Tbody>
                {notInterestedCustomers.map((customer, index) => (
                  <Tr key={index}>
                    {/* <Td fontSize={'11'}>{customer.srno}</Td> */}
                    {/* <Td fontSize={11} textAlign="center">
  <Img src={`./uploads/${customer.image}`} alt="profile" />
</Td> */}


                    <Td fontSize={'11'} textAlign={'center'}>{customer.date}</Td>
                    <Td fontSize={'11'} textAlign={'center'}>{customer.companyName}</Td>
                    <Td fontSize={'11'} textAlign={'center'}>{customer.office}</Td>
                    <Td fontSize={'11'} textAlign={'center'}> {customer.city}</Td>
                    <Td fontSize={'11'} textAlign={'center'}>  {customer.state}</Td>
                   <Td fontSize={'11'} textAlign={'center'}>{customer.customerName}</Td>
                    <Td fontSize={'11'} textAlign={'center'}>{customer.customerNumber}</Td>
                    <Td fontSize={'11'} textAlign={'center'}>{customer.email}</Td>
                    <Td fontSize={'11'} textAlign={'center'}>{customer.businessCategory}</Td>
                    <Td fontSize={'11'} textAlign={'center'}>{customer.requiredItem}</Td>
                    <Td fontSize={'11'} textAlign={'center'}>{customer.requiredQuantity}</Td>
                    <Td fontSize={'11'} textAlign={'center'}>{customer.productSpecific}</Td>
                    <Td fontSize={'11'} textAlign={'center'}>{customer.orderValue}</Td>
                    <Td fontSize={'11'} textAlign={'center'}>{customer.feasibility}</Td>
                    <Td fontSize={'11'} textAlign={'center'}>{customer.quotationSubmissionDate}</Td>
                    <Td fontSize={'11'} textAlign={'center'}>{customer.scheduledate}</Td>
                    <Td fontSize={'11'} textAlign={'center'}>{customer.followingResult}</Td>
                    {/* <Td fontSize={'11'} textAlign={'center'}>{customer.status}</Td> */}
                    <Td>
                      <Flex justifyContent="center">
                        <Button colorScheme="blue" h={6} w={5} variant="outline" onClick={() => handleEditCustomer(customer)} borderWidth="2px" mr={1}
                      
                    >
                      <EditIcon />
                    </Button>
                        <Button colorScheme="blue" h={6} w={5} variant="outline" borderWidth="2px"
                          onClick={() => deleteCustomer(customer._id)}
                        >
                          <DeleteIcon />
                        </Button>
                      </Flex>
                    </Td>
                  </Tr>
                ))}
              </Tbody>
            </Table>
          </Box>
        </Box>
      </Box>
  );
};

export default CRM;
