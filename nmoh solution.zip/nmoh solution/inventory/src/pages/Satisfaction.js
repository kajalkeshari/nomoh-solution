import React, { useState } from 'react';
import { Box, Heading, Text, Button, FormControl, FormLabel, Input, Textarea, Flex, Spacer, Select } from '@chakra-ui/react';

const CustomerSatisfaction = () => {
    const [feedback, setFeedback] = useState({
        name: '',
        email: '',
        rating: '',
        comment: ''
    });

    const handleInputChange = (e) => {
        const { name, value } = e.target;
        setFeedback({ ...feedback, [name]: value });
    };

    const handleSubmit = (e) => {
        e.preventDefault();
        // Send feedback data to backend or handle it as required
        console.log(feedback);
        // Reset feedback form after submission
        setFeedback({
            name: '',
            email: '',
            rating: '',
            comment: ''
        });
    };

    return (
        <Box p={6}  bg={'white'} w={'100%'} h={'100vh'} color={'navy'} borderWidth={'2px'}>
            <Heading fontSize={'24'} mb={4}>Customer Satisfaction</Heading>
            <Box p={20} borderWidth={'1px'} bg={''} borderColor={'Highlight'}>
                <form onSubmit={handleSubmit}>
                    <FormControl id="name" mb={4}>
                        <FormLabel>Name</FormLabel>
                        <Input type="text"  size={'sm'} borderColor={'Highlight'} name="name" value={feedback.name} onChange={handleInputChange} />
                    </FormControl>
                    <FormControl id="email" mb={4}>
                        <FormLabel>Email</FormLabel>
                        <Input type="email"  size={'sm'} borderColor={'Highlight'} name="email" value={feedback.email} onChange={handleInputChange} />
                    </FormControl>
                    <FormControl id="rating" mb={4}>
                        <FormLabel>Satisfaction Level</FormLabel>
                        <Select name="rating"  size={'sm'} borderColor={'Highlight'} value={feedback.rating} color={'gray'} onChange={handleInputChange}>
                            <option  value="">Select</option>
                            <option  value="1">Very Unsatisfied</option>
                            <option  value="2">Unsatisfied</option>
                            <option  value="3">Neutral</option>
                            <option  value="4">Satisfied</option>
                            <option  value="5">Very Satisfied</option>
                        </Select>
                    </FormControl>
                    <FormControl id="comment" mb={4}>
                        <FormLabel>Comment</FormLabel>
                        <Textarea name="comment"  size={'sm'} borderColor={'Highlight'} value={feedback.comment} onChange={handleInputChange} />
                    </FormControl>
                    <Flex justify="flex-end">
                        <Button type="submit" borderRadius={2} colorScheme="teal">Submit</Button>
                    </Flex>
                </form>
            </Box>
        </Box>
    );
};

export default CustomerSatisfaction;
