import React, { useState } from "react";
import { Box, Grid, Heading, VStack, Text, AccordionIcon ,GridItem, Flex, Img, Button} from "@chakra-ui/react";

import { Link, Outlet } from "react-router-dom";
import Main from "../Main";
import logo from '../pages/assets/logo.jpg'
import {LogoutuserAction} from  '../redux/authReducer/action'
import { useDispatch, useSelector } from "react-redux";

 
function Navbar() {
 const {isAuthenticated}= useSelector((state)=>state.authReducer)
 const dispatch= useDispatch();


 const handleLogout = () => {
dispatch(LogoutuserAction());

 }

  return (
    
    <Grid templateColumns="230px 1fr"  >
      {/* Sidebar */}
      <Box bg="white" color="navy" p={6} h={'100vh'}>
        <Img src={logo}/>
        <Heading textAlign="center" fontSize={'18'} mt={5} fontWeight={'800'} color={'blue.700'}>Sales Marketing </Heading>
     
        <Box mt={1} fontWeight={'bold'} >
            <VStack align="flex-start" p={2} > 
            <Link to={'/'}>
         <Text fontSize={'15'} fontWeight={'700'}> New Customer</Text>
            </Link> 
            <Link to={'/adjust_customer'}>
          <Text fontSize={'15'} fontWeight={'700'}>Adjusting Customer</Text>
            </Link>   



            <Link to={'/schedule'}>
          <Text fontSize={'15'} fontWeight={'700'}>Schedule</Text>
            </Link>


         
        <Link to={'/satisfy_customer'}>
         <Text fontSize={'15'} fontWeight={'700'}>Satisfaction</Text> 
        </Link>
        <Link to={'/order'}>
          <Text fontSize={'15'} fontWeight={'700'}>Order </Text>
        </Link>
          <Box>
            {isAuthenticated && isAuthenticated ? 
        <Box as="button" onClick={handleLogout}> 
        <Text fontSize={'15'} fontWeight={'700'}>Logout</Text>
        </Box>
        :''}
        </Box>
          </VStack>

        </Box>
      </Box>

      {/* Main Content */}
      <Flex >
      <Main/>
       
        <Outlet/>
    </Flex>
    </Grid>
  );
}

export default Navbar;


