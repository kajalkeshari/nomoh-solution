import React, { useState, useEffect } from "react";
import axios from 'axios';
import {
    Stack, Button, Text, Container, Heading, Box, Modal, useDisclosure, Select,
    ModalOverlay,
    ModalContent,
    ModalHeader,
    ModalFooter,
    ModalBody,
    ModalCloseButton,
    FormControl,
    FormLabel,
    Input,
    HStack,
} from "@chakra-ui/react";
import { EditIcon, DeleteIcon } from '@chakra-ui/icons'
import { Link } from "react-router-dom";
const  backend_url=process.env.REACT_APP_URL;

const Department = () => {
    const [showModal, setShowModal] = useState(false);
    const [users, setUsers] = useState([]);
    const [searchTerm, setSearchTerm] = useState('');
    const [formData, setFormData] = useState('');
    const { isOpen, onOpen, onClose } = useDisclosure();
    const [selectedInventory, setSelectedInventory] = useState(null);
    const [isAdding, setIsAdding] = useState(true);
    const [selectedInventoryId, setSelectedInventoryId] = useState(null);








    const handleAddModalOpen = () => {
        onOpen();
    };


    const handleUpdateModalOpen = (employee) => {
        setSelectedInventory(employee);
        setFormData({
            name: employee.name,
            email: employee.email,
            department: employee.department,
            password: employee.password

        });
        setIsAdding(false);
        onOpen();
        setSelectedInventoryId(employee._id);
    };

    useEffect(() => {
        fetchData();
    }, []);

    const fetchData = async () => {
        try {
            const response = await axios.get(`${backend_url}/api/read_employee`);
            console.log('Fetched data:', response.data);
            setUsers(response.data);
        } catch (error) {
            console.error('Error fetching data:', error);
        }
    };

    const handleInputChange = (e) => {
        setFormData({ ...formData, [e.target.name]: e.target.value });
    };


    const handleCreate = async () => {
        if (!formData.name || !formData.email || !formData.department) {
            alert('Please fill in all required fields.');
            return;
        }
        try {
            const postData = { name: formData.name, email: formData.email, department: formData.department };
            const response = await axios.post(`${backend_url}/api/add_employee`, postData);
            fetchData();
            setFormData({ name: '', email: '', department: '' });
            onClose();
            if (response.data.password) {
                alert(`User added successfully. Generated password: ${response.data.password}`);
            } else {
                alert('User added successfully');
            }
        } catch (error) {
            console.error('Error creating user:', error);
        }
    };








    const handleUpdate = async (id) => {
        if (!formData.name || !formData.email || !formData.department) {
            alert('Please fill in all required fields.');
            return;
        }
        try {
            await axios.put(`${backend_url}/api/update_employee/${selectedInventoryId}`, formData);
            fetchData();
            onClose();
            alert('Employee updated successfully');
        } catch (error) {
            console.error('Error updating employee:', error);
        }
    };


    const handleDelete = async (id) => {
        try {
            const confirmDelete = window.confirm('Are you sure you want to delete this employee item?');
            if (!confirmDelete) {
                return;
            }

            console.log('Deleting inventory item with ID:', id);
            await axios.delete(`${backend_url}/api/delete_employee/${id}`);
            fetchData();
            alert('Employee item deleted successfully');
        } catch (error) {
            console.log('Error deleting employee item:', error);
        }
    };






    const handleSearchChange = (e) => {
        setSearchTerm(e.target.value);
    };

    // const filteredUsers = users.filter((user) =>
    //     user.name.toLowerCase().includes(searchTerm.toLowerCase())
    // );


    // const employeeTypes = ["Employee", "Employer"];

    const departmentOptions = ["Marketing Excutive", "Marketing Manager"];



    return (
        <Box w={'100%'}  bg="white" h={'100%'} color="navy" mb='5' p={3} borderWidth={'2px'}>

            <Heading mb={'3'} mt={4} fontSize={'35'} textAlign={'center'} >
                Manage Department
            </Heading>


            <HStack justifyContent={'space-between'}>
                {/* <Link to={'/product_veri'}>
<Heading p={4} fontSize={'24'}>Product</Heading>
                </Link> */}

                <>
                    <Button borderWidth={'2px'} onClick={handleAddModalOpen} colorScheme="blue" fontWeight={'bold'} fontSize={'13'}  h={9} mb={4} mr={1} variant="outline">Add Employee</Button>
                    <Modal isOpen={isOpen} onClose={onClose}>
                        <ModalOverlay />
                        <ModalContent bg={'gray.700'} color={'gray.200'}>
                            <ModalHeader>{isAdding ? "Add Employee" : "Update Employee"}</ModalHeader>
                            <ModalCloseButton />
                            <ModalBody>
                                <FormControl>
                                    <FormLabel>Name</FormLabel>
                                    <Input type="text" name="name" value={formData.name} onChange={handleInputChange} />
                                </FormControl>
                                <FormControl mt={4}>
                                    <FormLabel>Email</FormLabel>
                                    <Input type="email" name="email" value={formData.email} onChange={handleInputChange} />
                                </FormControl>
                                <FormControl mt={4}>
                                    <FormLabel>Department</FormLabel>
                                    <Select color={'gray'} name="department" value={formData.department} onChange={handleInputChange}>
                                        {departmentOptions.map((department, index) => (
                                            <option key={index} value={department} color="red">{department}</option>
                                        ))}
                                    </Select>
                                </FormControl>

                            </ModalBody>

                            <ModalFooter>
                                <Button colorScheme="cyan" mr={3} variant={'outline'} borderWidth={'4px'} fontWeight={'bold'} onClick={isAdding ? handleCreate : handleUpdate}>
                                    {isAdding ? 'Add' : 'Update'}
                                </Button>
                                <Button variant="outline" borderWidth={'4px'} fontWeight={'bold'} colorScheme='white' onClick={onClose}>
                                    Close
                                </Button>
                            </ModalFooter>
                        </ModalContent>
                    </Modal>
                </>

                {/* <Input
                    w={'30%'}
                    type="text"
                    placeholder="Search......"
                    value={searchTerm}
                    width={'auto'}
                    fontSize={'12'}
                    borderColor={'blue'}
                    h={9}
                    mb={4}
                    borderWidth={'2px'}
                    onChange={handleSearchChange}
                /> */}

            </HStack>

            <Box borderWidth="1px" borderRadius="lg" overflow="hidden" >
                <Box display="flex" bg="blue.900" color={'white'} p={1} fontWeight="bold" justifyContent={'space-between'}>
                    <Box flex={2} textAlign={'center'}>Name</Box>
                    <Box flex={2} textAlign={'center'}>Email</Box>
                    <Box flex={2} textAlign={'center'}>Department</Box>

                    {/* {isAdding && <Box flex={2} p={2}>Password</Box>} */}
                    <Box flex={1} p={2}>Action</Box>
                </Box>
                {users.map((user) => (

                    <Box display="flex" bg="white" color={'white'} bgColor={'blue.700'} borderWidth="1px" justifyContent={'space-between'}>
                        <Box flex={2} textAlign={'center'}>{user.name}   </Box>
                        <Box flex={2} textAlign={'center'}>{user.email}   </Box>
                        <Box flex={2} textAlign={'center'}>{user.department}     </Box>
                        {/* <Box flex={2} p={2}>{user.password} */}
                        {/* </Box> */}


                        <Box flex={1} p={2} >
                            <Button borderWidth={'2px'} colorScheme="white" h={8} w={7} mr={1} variant="outline" onClick={() => handleUpdateModalOpen(user)}><EditIcon /></Button>
                            <Button borderWidth={'2px'} colorScheme="white" h={8} w={7} variant="outline" onClick={() => handleDelete(user._id)}><DeleteIcon /></Button>

                        </Box>


                    </Box>
                ))}
            </Box>


        </Box>
    );
};

export default Department;
