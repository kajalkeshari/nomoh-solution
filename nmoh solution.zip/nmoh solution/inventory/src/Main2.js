import React from 'react';
import { BrowserRouter as Router, Routes, Route, Link } from 'react-router-dom';
import Inventory from './pages/Inventory';
import ManageInventory from './pages/ManageInventory';
import VerifyProduct from './pages/VerifyProduct';
import RejectProduct from './pages/RejectProduct';
import Department from './pages/Department';






function Main2() {
  return (
    // <Router>
      <Routes>
         <Route path="/" element={<Inventory/>} /> 
        <Route path="/product_verify" element={<VerifyProduct/>} />
        <Route path="/manage_inventory" element={<ManageInventory/>} /> 
        <Route path="/reject_inventory" element={<RejectProduct/>} /> 
        <Route path="/manage_department" element={<Department/>} /> 
       

      </Routes>
    // </Router>
  );
}

export default Main2;
