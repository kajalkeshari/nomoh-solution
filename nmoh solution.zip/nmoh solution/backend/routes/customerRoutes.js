  const express = require('express');
  const router = express.Router();
  const Customer= require('../model/customerSchema.js')
  // const upload = multer({ dest: 'uploads/' });
  const multer = require('multer');
  const path = require('path');
  const fs = require('fs');
  // const imageUrl = `http://localhost:4000/uploads/${customer.image}`;


  router.use('/uploads', express.static(path.join(__dirname, 'uploads')));




  // Get all customers
  router.get("/read_customers", async (req, res) => {
      try {
        const customers = await Customer.find();
      
        res.json(customers);
      } catch (error) {
        console.error("Error fetching customers:", error);
        res.status(500).json({ error: "Internal server error" });
      }
    });
    


    
    router.get('/uploads/:imageName', (req, res) => {
      const imageName = req.params.imageName;
    
     // Adjust 
        const filePath = path.join('uploads', imageName); 
  
         console.log(imageName)
         console.log(filePath)
       
      try {
        // Read the image file synchronously
        fs.readFile(filePath, (err, data) => {
          if (err) {
            console.error(err);
            res.status(500).send('Error reading image file');
            return;
          }
  
          // Set the appropriate headers and send the image data as the response
          res.writeHead(200, {
            'Content-Type': 'image/jpeg',
            'Content-Length': data.length
          });
          res.end(data);
        });
     }   catch (error) {
        console.error('Error reading image:', error);
        res.status(500).send('Error reading image.');
      }
  
  
    });
    
    router.get('/find/image', (req, res) => {
      // Read the files in the 'uploads' directory
      fs.readdir('uploads', (err, files) => {
        if (err) {
          console.error('Error reading directory:', err);
          res.status(500).send('Error reading directory.');
          return;
        }
    
        // Send the list of filenames in the response
        res.json({ files });
      });
    });



    
  // Get customers by status
  router.get("/read_customers", async (req, res) => {
    const { date } = req.query;
    try {
        let customers;
        if (date) {
            customers = await Customer.find({ date });
        } else {
            customers = await Customer.find();
        }
        res.json(customers);
    } catch (error) {
        console.error("Error fetching customers:", error);
        res.status(500).json({ error: "Internal server error" });
    }
  });





  // Multer storage configuration
  const storage = multer.diskStorage({
    destination: function (req, file, cb) {
      cb(null, 'uploads/'); // Define the destination directory
    },
    filename: function (req, file, cb) {
      cb(null, file.fieldname + "_" + Date.now() + path.extname(file.originalname)); // Define the filename
    }
  });

  const upload = multer({ storage: storage }).single('image');



  // Image upload route
  router.post('/upload', upload, async (req, res) => {
    try {
      if (!req.file) {
        return res.status(400).json({ error: "No file uploaded" });
      }

      const imageFile = req.file.filename; // Get the uploaded file name

      res.status(200).json({ success: `${imageFile} uploaded successfully` });
    } catch (error) {
      console.error("Error uploading image:", error);
      res.status(500).json({ error: "Internal server error" });
    }
  });

  router.post("/add_customer", upload, async (req, res) => {
    console.log(req.file,req.body)
  
    const { 
      date,
      // srno,
      companyName,
      office,city,state,
      customerName,
      customerNumber,
      email,
      scheduledate,
      businessCategory,
      requiredItem,
      requiredQuantity,
      productSpecific,
      orderValue,
      feasibility,
      quotationSubmissionDate,
      followingResult,
      status,
    
      
    } = req.body;
    // const image = req.file.path

    try {
    
      const newCustomer = new Customer({
        date,
        // srno,
        companyName,
        office,city,state,
        customerName,
        scheduledate,
        customerNumber,
        email,
        businessCategory,
        requiredItem,
        requiredQuantity,
        productSpecific,
        orderValue,
        feasibility,
        quotationSubmissionDate,
        followingResult,
        status,
        // image: req.file.path
    
      });

      await newCustomer.save();
      res.status(201).json({ message: "Customer added successfully" });
    } catch (error) {
      console.error("Error adding customer:", error);
      res.status(500).json({ error: "Internal server error" });
    }
  });

    // Delete a customer
    router.delete("/delete_customer/:id", async (req, res) => {
      const customerId = req.params.id;
      try {
        await Customer.findByIdAndDelete(customerId);
        res.json({ message: "Customer deleted successfully" });
      } catch (error) {
        console.error("Error deleting customer:", error);
        res.status(500).json({ error: "Internal server error" });
      }
    });
    
    // Update a customer
  
  // Update a customer
  router.put("/update_customer/:id", upload, async (req, res) => {
    const customerId = req.params.id;
    
    const { 
      date,
      companyName,
      office, city, state,
      customerName,
      customerNumber,
      email,
      scheduledate,
      businessCategory,
      requiredItem,
      requiredQuantity,
      productSpecific,
      orderValue,
      feasibility,
      quotationSubmissionDate,
      followingResult,
      status,
    } = req.body;

    try {
      const updatedCustomer = await Customer.findByIdAndUpdate(
        customerId,
        {
          date,
          companyName,
          office, 
          city, 
          state,
          customerName,
          customerNumber,
          email,
          scheduledate,
          businessCategory,
          requiredItem,
          requiredQuantity,
          productSpecific,
          orderValue,
          feasibility,
          quotationSubmissionDate,
          followingResult,
          status,
          image: req.file ? req.file.filename : undefined, 
        },
        { new: true } 
      );

      if (!updatedCustomer) {
        return res.status(404).json({ error: "Customer not found" });
      }

      res.json({ message: "Customer updated successfully", customer: updatedCustomer });
    } catch (error) {
      console.error("Error updating customer:", error);
      res.status(500).json({ error: "Internal server error" });
    }
  });




    module.exports = router;