const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');
const inventoryRoutes = require('./routes/inventoryRoutes');

const departmentRoutes = require('./routes/departmentRoutes');
const customerRoutes = require('./routes/customerRoutes');
const productRoute = require('./routes/ProductRoute')
// const authRoutes = require('./routes/authRoutes');
const multer = require('multer');
// const upload = multer({ dest: 'uploads/' });
const bodyParser = require('body-parser');
const flash = require('connect-flash');
const passport = require('passport'); 
const session = require('express-session');
const cookieParser = require('cookie-parser');
const dotenv = require('dotenv')
const path=require('path')
const app = express();
dotenv.config();

const router = express.Router(); 



app.use(express.json());
app.use(session({ secret: 'secret', resave: false, saveUninitialized: false }));
app.use(passport.initialize());
app.use(passport.session());
app.use(flash());
app.use(bodyParser.json());
app.use(cookieParser());
app.use(cors({
    origin: true,  
    methods: 'GET,HEAD,PUT,PATCH,POST,DELETE',
    credentials: true,  
  }));
// app.use('/',express.static('uploads'));




router.use('/api', inventoryRoutes);

router.use('/api', departmentRoutes);
router.use('/api', customerRoutes);
router.use('/api', productRoute)

// router.use('/api', authRoutes);



app.use(function(req, res, next) {
    res.header('Access-Control-Allow-Credentials', true);
    res.header('Access-Control-Allow-Origin', req.headers.origin);
    res.header('Access-Control-Allow-Methods', 'GET,PUT,POST,DELETE,UPDATE,OPTIONS');
    res.header('Access-Control-Allow-Headers', 'X-Requested-With, X-HTTP-Method-Override, Content-Type, Accept');
    next();
  });

  app.use(express.static(path.join(__dirname, './frontend/build')));






// MongoDB Connection
mongoose.connect(process.env.MONGO_URL).then(() => {
    console.log('database connected');
}).catch(err => {
    console.error('Error connecting to MongoDB:', err);
});




// Use the router middleware
app.use(router);


app.get('*', (req, res) => {
  res.sendFile(path.join(__dirname, './frontend/build/index.html'));
});



const PORT = process.env.PORT || 8000;
app.listen(PORT, () => {
    console.log(`Server is running on port ${PORT}`);
});
